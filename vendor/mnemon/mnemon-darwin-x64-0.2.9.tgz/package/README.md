# Mnemon darwin-x64

Native darwin/x64 artifact for `@mnemon-dev/mnemon@0.2.9-darwin-x64`. Install `@mnemon-dev/mnemon` instead of this platform artifact directly.
