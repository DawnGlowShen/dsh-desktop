# Mnemon darwin-arm64

Native darwin/arm64 artifact for `@mnemon-dev/mnemon@0.2.9-darwin-arm64`. Install `@mnemon-dev/mnemon` instead of this platform artifact directly.
