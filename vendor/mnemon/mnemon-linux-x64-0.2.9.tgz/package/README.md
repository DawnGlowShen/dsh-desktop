# Mnemon linux-x64

Native linux/x64 artifact for `@mnemon-dev/mnemon@0.2.9-linux-x64`. Install `@mnemon-dev/mnemon` instead of this platform artifact directly.
