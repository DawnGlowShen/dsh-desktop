# EdanSpec Qt C++ adapter

This file is an integration override, not a new Qt checklist. Read `SKILL.md` and the original `references/qt-review-checklist.md`. Read `qt-framework-checklist.md` only after the user explicitly authorizes framework mode. Upstream source and license are recorded in `../UPSTREAM.json` and `../LICENSE.txt`.

## Fixed input and read-only boundary

Use the caller's `stackId`, `projectRoot`, `scopeMode`, revision, matched files, changed lines, guidance and matching evidence. Do not select another diff or scan the repository as a new report scope. Related model/type/build/call-chain files are read-only context. Do not call `qt-qml-review` or edit business code, configuration, Skills or lessons learned.

## Required execution

1. Determine the project's actual Qt major/minor version from build/version context. These resources target Qt 6; Qt 5, unknown versions and inapplicable rules must be disclosed and may require `partial` status. Framework mode remains opt-in.
2. Run this Skill's unchanged `references/lint-scripts/qt_review_lint.py` with only the caller's existing `lintFiles`. Preflight readable inputs and record the actual command, exit code and raw output. A diagnostic exit is not the same as a tool execution failure.
3. Cover all six upstream analysis missions: model-contracts, ownership-lifecycle, thread-safety, api-cpp, error-handling and performance-quality. Missing a direction is `partial`.
4. Produce the upstream raw Qt report and the result object required by the caller. Save raw output only where authorized; otherwise set `rawReportPath` to empty/null.

## Result and limitations

Keep the original lint/checklist IDs, rule IDs, file locations, evidence, recommendations, severity reasoning and any supplied confidence. Confidence is independent of severity. Findings outside the caller's report scope are excluded or listed as unconfirmed investigation targets.

Python missing, required lint failure or incomplete analysis is `partial`; crashes, timeouts and invalid arguments are execution errors. Qt version limitations must be explicit. Do not treat every lint diagnostic as a confirmed or critical defect.

Universal rules remain in the upstream references; this file only defines the EdanSpec adapter workflow. Project guidance is under `projectRoot/.edan-dev/review-notes/`.
