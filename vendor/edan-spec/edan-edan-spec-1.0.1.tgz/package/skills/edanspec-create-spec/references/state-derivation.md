# 状态推导规则

本文件是**产物状态**与 **spec 冲突**的唯一判定依据。全部从文件系统事实推导，**不需要任何脚本或解释器**——用目录列举与读文件即可核对，离线/内网环境同样可用。

## 一、产物状态

对目标 feature 目录 `EdanSpec/feature/{name}/` 逐项判定。

| 产物 | done 条件 | 依赖 |
|------|-----------|------|
| `proposal` | `proposal.md` 存在且非空（字节数 > 0） | 无 |
| `specs` | `specs/` 下存在至少一个 `*-spec.md` | `proposal` |
| `design` | `design.md` 存在且非空 | `proposal` |

状态计算（按上表顺序执行；已判为 done 的产物计入「依赖已满足」集合）：

1. 满足 done 条件 → `done`
2. 不满足，但全部依赖均为 `done` → `ready`
3. 不满足，且存在未 done 的依赖 → `pending`

`specs` 与 `design` 都只依赖 `proposal`，彼此无依赖。

> `specs` 的 done 判定**只看「至少有一个 spec 文件」**。spec 文件数是否等于 proposal 中 `New + Modified Capabilities` 条目总数，属于 SKILL.md「验证」章节的自检项，不改变本状态。

## 二、批量扫描

列出 `EdanSpec/feature/` 下所有子目录，对每个套用上面的规则。该目录不存在 → 尚无任何 feature。

## 三、恢复流程取用

- 第一个 `ready` 的产物 → 从它继续生成
- 全部 `done` → 方案完成，引导 `edanspec-task-plan`
- 全部 `pending` → 从零开始

## 四、spec 冲突检测

在生成 specs **之前**执行，检测当前 feature 是否会与其它活跃 feature 改同一 capability。

1. 列出 `EdanSpec/feature/*/specs/*-spec.md`，**排除当前 feature 自身**
2. 文件名去掉后缀 `-spec.md` → capability 名
3. **归一化**：删除所有 `-` 和 `_`，转小写（`user-auth` → `userauth`，`Authentication` → `authentication`）
4. 与当前 feature 的每个 capability 名两两比较，命中任一即为冲突：
   - `identical` — 归一化后完全相同（`auth` vs `auth`）
   - `prefix_match` — 归一化后互为前缀且两者不相等（`auth` vs `authentication`）
5. 发现冲突 → 展示警告（涉及哪个 feature、哪个 spec、哪种冲突），用户确认后追加到当前 feature 的 `status.json` 的 `conflicts` 字段

`conflicts` 条目格式：

```json
{
  "feature_a": "20260518-login",
  "spec_a": "auth",
  "feature_b": "20260520-sso",
  "spec_b": "authentication",
  "reason": "prefix_match"
}
```

冲突不阻塞实现，但必须在归档前解决（见 `edanspec-archive`）。
