---
name: edanspec-create-spec
description: 为需求创建或更新方案文档。**触发场景：** 新功能、"做一个XX"、"加个XX"、"继续上次"、"方案调整"、"需求变了"。**不适用：** 一行修复、拼写错误、纯调研。**先判档位：** 小改动（≤2 文件、≤50 行）走 SLIM 档，只产出 change.md，不建完整方案文档；STD/FULL 档生成 proposal + specs + design。
---

<!-- STATE_RULES: references/state-derivation.md（相对本 SKILL.md 所在目录）。产物状态与 spec 冲突全部由该文件的规则从文件事实推导，不依赖任何脚本或解释器，离线/内网环境同样可用 -->

# Create Spec

为需求创建或更新方案文档，一个 feature 目录 = 完整上下文。**先想清楚再动手**——但想多久要跟改动大小匹配。

## 步骤零：判定执行档位

**先判档，再决定写多少文档。** 依据用户描述（必要时 grep 定位涉及文件）预估改动规模，在回复里亮出结论（一两行，用户一句话即可改档）。

| 档 | 判定条件（需全部满足） | 产物 | 后续 |
|---|------|------|------|
| **SLIM** | 改动 ≤2 文件 且 ≤50 行；不改接口/契约/依赖/schema/配置项；不触安全敏感面；非破坏性 | 仅 `change.md` + `status.json` | 跳过 task-plan，直接实现 → 归档 |
| **STD** | ≤7 文件；单模块；无架构变更、无新依赖、无 schema / 安全模型变更 | proposal + specs + design | task-plan → implement（一次合并审查）→ archive |
| **FULL** | 其余全部情况：≥8 文件 / 跨模块 / 架构变更 / 新第三方依赖 / schema 变更 / 安全模型变更 / 破坏性变更 | 现有全部 | 现有全流程 |

**判定优先级**：用户显式指定 > 上表自动判定。用户说「走完整流程」→ FULL；说「小改一下」→ 倾向 SLIM。

**判不准时不判 SLIM**：需求描述模糊、无法预估涉及文件、或本身就在澄清阶段 → 按 STD 起步。**模糊的需求从来不是小改动。**

**不可裁剪项（任何档位都不省）**：改动必须有验证证据、安全红线必查（用户输入 / 认证 / 密钥 / SQL / 文件上传 / 外部请求）、范围纪律、原子提交、破坏性变更需授权。

**升级闸门**：实现中发现实际范围超出所判档位 → 立即停下，告知用户，升级档位并补齐产物。不得硬撑。

---

## SLIM 轻通道

判定为 SLIM 时，**不**生成 proposal / specs / design，只做三件事：

1. 建目录与状态文件（步骤 2 的命令，`specs/` 可省）
2. 写 `EdanSpec/feature/{timestamp}-{topic}/change.md`：

```markdown
# {topic}

## 改什么

- `path/to/file`：[具体改动]

## 为什么

[1-2 句：解决什么问题]

## 验收标准

- [ ] [可验证的期望结果；能给验证命令就给]

## 验证

<!-- 实现完成后由 edanspec-task-implement 的 6.6 自检填写：实际执行的命令与结果 -->
```

3. 报告「已按 SLIM 档建轻工单」→ 引导调用 `edanspec-task-implement` 直接实现

> SLIM 省掉的是**文书厚度与关卡隔离**，不是验证。change.md 的「验证」段必须在实现后填上实际命令与结果，否则归档会被拒绝（见 `edanspec-archive` 2.5）。

---

## 自动识别场景

启动时自动判断当前场景，不要求用户手动选择。**仅 STD / FULL 档需要本节**——SLIM 档按上面的轻通道走完即可。

1. 扫描 `EdanSpec/feature/` 下所有子目录，按 `references/state-derivation.md` 的规则推导各 feature 的产物状态
2. 扫描所有 feature 的 `status.json`，收集 `state = "completed"` 的 feature 列表
3. **遗留归档检查**：如果存在已完成的未归档 feature，使用 **AskUserQuestion** 让用户选择：

| 问题 | "有已完成但未归档的 feature：`{列表}`，是否先归档？" |
|------|--------|
| **header** | "遗留归档" |
| **选项 1** | "先归档，再继续" → 引导调用 `edanspec-archive`，归档完成后继续后续流程 |
| **选项 2** | "暂不处理，继续原流程" → 接受，不阻塞，继续自动识别场景分流 |

4. 根据匹配结果分流：

| 检测结果 | 场景 | 下一步 |
|----------|------|--------|
| 无活跃 feature | **新建** | 新建流程 |
| 1 个活跃 feature，对话指向同一需求 | **恢复** | 恢复流程 |
| 1 个活跃 feature，用户描述明显不同的新需求 | **新建** | 确认旧 feature 后创建新的 |
| 2+ 活跃 feature | 歧义 | 列出选项让用户选择 |

判断"同一需求"的依据：用户描述中的关键词与 feature name / proposal.md 标题的语义匹配度。

## 目录结构

```
EdanSpec/feature/{timestamp}-{topic}/
├── proposal.md            # 为什么做、影响范围
├── specs/                 # 需求规格（验收条件）
│   └── {capability}-spec.md
├── design.md              # 技术设计（实现方案）
├── tasks.md               # 任务清单（task-plan 阶段生成，checkbox 进度唯一来源）
├── review/                # 正式评审产物（可选）
├── change.md              # SLIM 档专用（轻量替代 proposal+specs+design）
└── status.json            # 元数据（state / conflicts）
```

一个变更 = 一个目录：feature 目录聚合本次变更的全部交付物，贯穿整个生命周期——方案（本技能）→ 任务（task-plan）→ 实现与审查（task-implement）→ 归档（archive）。

产物状态（proposal/specs/design 是否完成）从文件系统事实推导，不写入 status.json。**判定规则见 `references/state-derivation.md`，无需运行任何脚本。**

## 产物依赖图

```
                proposal
                   │
              ┌────┴────┐
              ▼         ▼
           specs      design
```

`specs` 和 `design` 都依赖 `proposal`，但两者之间无依赖。产物状态从文件存在性自动推导（规则见 `references/state-derivation.md`），全部完成 → 引导进入 task-plan。

## 恢复流程

从文件系统事实恢复上下文，不依赖会话记忆。

1. 按 `references/state-derivation.md` 推导各 artifact 状态
2. 找到第一个 `ready` 的 artifact → 从它开始继续
3. 全部 done → 方案已完成，引导进入 task-plan
4. 全部 pending → 从零开始
5. 无活跃 feature → 进入正常流程（新建）
6. 只有 `change.md` → 这是 SLIM 档工单，引导进入 task-implement，不补方案文档

## 变更流程

详见 [references/change-workflow.md](references/change-workflow.md)。用户在已有方案基础上提出修改时：

1. 重新读取 `proposal.md`、`specs/`、`design.md`，理解当前方案全貌
2. 根据用户变更意图，从头生成所有产物——不是局部修改，而是完整重写，确保各文件之间逻辑一致
3. 将旧文件替换为新内容（不追加、不遗留历史标记），保留 git 历史即可追溯差异
4. 完成后展示变更摘要，让用户确认改了什么

> 若这次变更本身很小（符合 SLIM 条件），不要走上述重写流程——直接走 SLIM 轻通道建一个新的轻工单更划算。

## 新建流程

### 步骤 1 — 确认范围

从用户描述中提取：要解决什么问题？涉及哪些模块/文件？有没有约束条件？

信息不够时，按 [references/clarification-guide.md](references/clarification-guide.md) 逐步澄清。描述已清晰则跳过。

> 澄清轮次与档位挂钩：SLIM 档最多澄清 1 轮（问最关键的歧义即可），STD 最多 2 轮，FULL 最多 3 轮。**澄清轮次够不上"想清楚"的，说明档位判低了。**

### 步骤 2 — 创建 feature 目录和 status.json

```bash
TIMESTAMP=$(date +%Y%m%d%H%M%S)
NAME="${TIMESTAMP}-${topic}"
mkdir -p "EdanSpec/feature/${NAME}/specs"
mkdir -p "EdanSpec/specs"
mkdir -p "EdanSpec/archive"
```

初始化 `status.json`：

```json
{
  "name": "20260520-user-login",
  "created": "2026-05-20T10:00:00",
  "base_commit": "abc1234",
  "state": "active",
  "designReviewState": "none",
  "conflicts": []
}
```

### 步骤 3 — 冲突检测

生成 specs 前，按 `references/state-derivation.md` 第四节检测冲突：扫描所有活跃 feature 的 `specs/`，基于文件名归一化（去连字符/下划线、转小写）和前缀匹配判断（如 `auth-spec.md` vs `authentication-spec.md`）。发现冲突则展示警告，用户确认后记录到 `status.json.conflicts`。

> SLIM 档无 specs，跳过本步骤。

### 步骤 4 — 按依赖图顺序生成产物

依赖顺序：`proposal` → `specs` + `design`（后两者无依赖，可任意顺序）。

**流程**：每次生成一个 artifact 前，按 `references/state-derivation.md` 确认依赖已就绪。逐个处理而非并行——每个 artifact 生成时可能需要向用户提问，同时进入澄清阶段会让用户收到多个问题，体验混乱。

> **STD 档精简**：不需要逐个 artifact 往返确认。一次把 proposal + specs + design 生成完，然后统一展示摘要让用户一次性确认——省掉的是往返次数，不是产物本身。

#### 步骤 4.1 — 提案（proposal.md）

**前置**：无依赖，第一个生成。

**生成前先分类**：对每个能力判断是 New 还是 Modified。
1. 读取 `EdanSpec/specs/` 下已归档的主规格，了解系统已有哪些能力
2. 在代码库中搜索对应实现（grep 关键词、搜索相关文件）
3. 归档 spec 中存在 或 代码中已实现 → Modified（**包括删除已有功能**），两者都不存在 → New

提案格式，小功能可以极简：

```markdown
# {Topic} 提案

## Why

[1-2 句话，解决什么问题/什么机会]

## What Changes

- [变更要点，列点]

## Capabilities

### New Capabilities
<!-- 新增的能力。每个创建 specs/<name>-spec.md -->
- `<name>`：[此能力覆盖的范围]

### Modified Capabilities
<!-- 需求发生变更的已有能力。每个也需创建 specs/<existing-name>-spec.md，使用 MODIFIED 分区描述变更。无变更则留空或删除此小节 -->
- `<existing-name>`：[哪个需求在变更，变更了什么]

## Impact

- `path/to/file`：[变更内容]
```

#### 步骤 4.2 — 规格（specs/{capability}-spec.md）

**前置**：proposal.md 已生成。

**生成规则**：proposal 中 `New Capabilities` 和 `Modified Capabilities` 下的每一项都必须生成对应的 `specs/<name>-spec.md` 文件，不得遗漏。

**New Capabilities** 使用 `## ADDED Requirements` 分区——描述全新引入的功能和验收条件：

```markdown
# {Capability} 规格

## ADDED Requirements

### Requirement: {名称}

{做什么}。

#### Scenario: {场景名}

- **WHEN** {触发条件}
- **THEN** {预期结果}
```

**Modified Capabilities** 使用 `## MODIFIED Requirements` 分区——描述已有需求中哪些条款在变更，需同时给出变更后的期望行为和回归场景：

```markdown
# {Capability} 规格

## MODIFIED Requirements

### Requirement: {被修改的需求名称}

{变更说明：原行为 → 新行为}。

#### Scenario: {变更场景名}

- **WHEN** {触发条件}
- **THEN** {变更后的预期结果}
```

首次创建且不影响已有能力时，只有 `## ADDED Requirements` 分区。涉及已有能力变更时才会出现 `## MODIFIED Requirements` / `## REMOVED Requirements` / `## RENAMED Requirements` 分区（见 change-workflow.md）。

> **Delta Spec ≠ 主规格**：此处生成的 `specs/{capability}-spec.md` 是增量变更，使用分区标题声明操作类型。归档合并时，分区标题作为操作指令被消耗，需求会被放入主规格（`EdanSpec/specs/`）的 `## Requirements` 扁平容器下。

Spec 是验收条件（what），不是实现方案（how）。代码结构、算法选型、数据库设计属于 design.md。模糊词（"应该""大概""可能"）意味着需求还没有想清楚——每条 spec 必须能被测试验证。

#### 步骤 4.3 — 设计（design.md）

**前置**：proposal.md 已生成（不依赖 specs）。

生成前先读取 [references/design-guide.md](references/design-guide.md)。

已有项目时沿用现有技术栈——自行更换框架会制造技术债和认知维护成本成倍增长。新项目参考 `references/platform-*.md` 逐项确认技术选型。

> **STD 档精简**：design.md 保留「设计目标 / 技术决策 / 风险与应对」三个必要小节即可。**每个决策两种方案对比**是 FULL 档的要求——STD 档只需在决策有真实取舍时写出被放弃的选项，不要为凑格式编造对比方案。

### 步骤 5 — 完成判定

所有产物生成后：按 `references/state-derivation.md` 确认所有条目为 `done` 且文件真实存在 → 评估是否需要 design-review。

触发 design-review 引导的信号（任一满足）：3 个以上模块/文件变更、引入新的第三方依赖、架构层面变更 / 多系统集成 / 跨服务调用、安全/权限模型变更 / 数据库 schema 变更 / 性能有严格要求。

引导话术：
> "检测到架构层面变更，建议先出详细设计方案再拆分任务（如当前环境有 design-review 技能可调用）。也可以先跳过，直接拆分任务。要继续吗？"

- 继续 → 更新 `designReviewState: "recommended"`，引导调用 design-review（如有）
- 跳过 → 更新 `designReviewState: "skipped"`，进入步骤 6
- 无需 review → `designReviewState` 保持 `"none"`，直接进入步骤 6

### 步骤 6 — 下一步

报告产物清单 → 提示调用 `edanspec-task-plan` 技能拆分任务。

## 状态管理

### 产物状态

按 `references/state-derivation.md` 从文件存在性推导，每次需要时重新推导，不缓存旧状态。三种状态：

| 状态 | 含义 |
|------|------|
| `done` | 文件存在且非空 |
| `ready` | 文件不存在或为空，但依赖已就绪 |
| `pending` | 文件不存在或为空，且依赖未满足 |

计算按依赖顺序进行：proposal → specs/design → 三者都 done 后引导进入 task-plan。

### Feature 生命周期（state）

```
active ──(全部任务+审查完成)──→ completed ──(归档)──→ archived
  │
  └──(用户放弃)──→ abandoned
```

| 值 | 含义 | 何时写入 |
|---|---|---|
| `active` | feature 进行中 | create-spec 初始化 |
| `completed` | 全部任务 + 审查关卡通过，待归档 | task-implement 步骤六完成后 |
| `archived` | 已移入 `EdanSpec/archive/` | archive 移动文件后 |
| `abandoned` | 用户主动放弃 | 用户明确说放弃时 |

## 验证

产物完成后逐项自检，全部打勾后再展示给用户。

### 文件完整性

- [ ] `proposal.md` 存在且非空
- [ ] `specs/` 目录下的 spec 文件数量 = proposal 中 `New Capabilities` + `Modified Capabilities` 的条目总数（不得遗漏）
- [ ] `design.md` 存在且非空
- [ ] 按 `references/state-derivation.md` 推导，所有 artifact 为 done

### 内容质量

- [ ] `proposal.md` 包含 Why / What Changes / Capabilities / Impact 四个章节
- [ ] Capabilities 分类正确：代码中已有的功能（含删除）归入 Modified，真正从零开始的功能归入 New
- [ ] 每条 spec 描述明确可验证的需求，包含至少一个 `Scenario`
- [ ] spec 中无模糊词（"应该""大概""可能""或许"）
- [ ] spec 使用分区格式（`## ADDED Requirements` 或 `## MODIFIED Requirements`），而非行内标签 `[ADDED]`
- [ ] `design.md` 包含设计目标（Goals）、技术决策（Decisions）、风险与应对
- [ ] `design.md` 中每个技术决策有至少两种方案对比（**FULL 档要求**；STD 档只需对真有取舍的决策写出被放弃的选项）
- [ ] `design.md` 沿用项目已有技术栈，未自行更换框架

### 状态一致性

- [ ] 按 `references/state-derivation.md` 推导的 artifact 状态与文件存在情况一致

### 流程完整

- [ ] 档位判定正确，且判定结果已向用户亮出
- [ ] 场景识别正确（新建 / 恢复 / 变更）
- [ ] 新建时已初始化 `status.json`（state=active, conflicts=[]）
- [ ] 变更时完整重写了所有产物（非局部追加、使用分区格式）
- [ ] 恢复时已按 `references/state-derivation.md` 推导状态
- [ ] 已评估是否需要 design-review，并正确设置 `designReviewState`
- [ ] SLIM 档：只生成 `change.md`，未多余生成 proposal/specs/design

## 常见误区与警示信号

> 通用误区见 `AGENT.md`。

| 说辞 | 真相 |
|------|------|
| "需求很清楚了直接写代码吧" | 5 分钟确认比 5 小时返工划算 |
| "spec 写太细了没必要" | spec 不是文档，是可验证的验收条件 |
| "反正后面还会改，现在随便写写" | 方案的价值是写之前想清楚 |
| "改动小，文档就随便写写，反正走 SLIM" | SLIM 减的是文档量，不是想清楚的程度。change.md 也要能被验证 |
| "都判 SLIM 了，顺手把接口也改了吧" | 碰到接口/依赖/schema/安全面 → 升级档位，不硬撑 |

出现以下任一信号时立即停下来修正：用户描述都没读完就开始生成 · spec 里出现"应该""大概"等模糊词 · design 自行更换了项目已有的技术栈 · 未检测冲突就生成 spec · 实际范围已超 SLIM 条件却仍按轻通道走。

## 辅助资源（按需加载）

- `references/state-derivation.md` — 产物状态与 spec 冲突的判定规则（无脚本，离线可用）
- `references/change-workflow.md` — 已有方案上的变更流程
- `references/clarification-guide.md` — 需求澄清指引
- `references/design-guide.md` — 设计文档生成指引
- `references/platform-*.md` — 各平台技术选型参考
