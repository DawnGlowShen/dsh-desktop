# EdanSpec Qt QML adapter

Integration override only. Keep the upstream `qt-qml-review-checklist.md`, six missions, Python lint and raw report format. Source and license: `../UPSTREAM.json` and `../LICENSE.txt`.

## Fixed scope

Consume the caller's `stackId`, `projectRoot`, `scopeMode`, revision, matched files, changed lines, guidance and matching evidence. Do not select another diff, scan the repository as a new report range or call `qt-cpp-review`. Related C++/imports/types are read-only context. `.qmltypes` is type context, not an interface component; it requires a separately specified rule set before direct review.

## Required execution

1. Record the actual project Qt version, including per-module differences. Qt 5, unknown versions and inapplicable rules must be disclosed; incomplete applicable coverage is `partial`.
2. Run this Skill's unchanged `references/lint-scripts/qt_qml_lint.py` with only the caller's `lintFiles`. Preflight readable inputs and record the actual command, exit code and raw output.
3. Run `qmllint` when available, using the version-supported options and project import paths. It is optional; missing `qmllint` is recorded as skipped and does not alone fail the review. Missing imports/dependencies are environment limitations, not automatically business defects.
4. Cover all six analysis missions: bindings-properties, layout-anchoring, loading-lifecycle, delegates, states-structure and performance-quality. Missing a direction is `partial`.
5. Produce the upstream raw QML report and the caller result object. Save raw output only where authorized; otherwise set `rawReportPath` to empty/null.

## Result and limitations

Keep original rule IDs, file locations, evidence, recommendations, severity reasoning and any supplied confidence. Confidence is independent of severity. Findings outside the caller's scope are excluded or listed as unconfirmed investigation targets.

Python missing, required lint failure or incomplete analysis is `partial`; `qmllint` absence alone is an optional limitation. Crashes, timeouts and invalid arguments are execution errors. Project configuration/guidance and Skill resources remain read-only.
