# EdanSpec 专项输入输出契约

本文件只定义通用入口与专项 Skill 之间的约定，不包含 Qt 检查清单。专项规则仍由各自 Skill 的 `references/` 维护。

## 固定范围

通用入口在调用任何 reviewer 前固定以下信息，并原样传给每个专项：

```text
projectRoot
scopeMode: diff / commit / directory
base/head 或其他明确的变更基准
allFiles
changedLines（变更审查时）
```

范围应包含新增、删除、重命名和带空格的路径。删除文件只能作为旧内容上下文分析，不能传给只接受现存文件的 lint。报告范围只允许产生本次发现；关联调用方、类型、构建目标等文件只能作为定向上下文。

仓库存在 `.codegraph/` 时按项目约定查询；没有时使用普通搜索，不自动创建索引。历史审查不能用当前工作树代替指定提交。

## 配置和匹配

只读取被审查项目根目录的 `.edan-dev/review-stack.yaml`。配置缺失时只执行通用审查，不生成配置。

配置项至少包含 `id`、`enabled`、`skill` 和 `match.extensions`，可选 `content_any`、`build_any`、`guidance`。入口必须拒绝重复 ID、错误字段类型、无效正则、不支持版本、无法读取的 guidance，并将错误记入最终报告。

候选文件是 `allFiles` 中扩展名匹配的文件：

- `content_any` 和 `build_any` 都未配置：候选文件全部匹配；
- 任一条件已配置：源码命中 `content_any`，或有证据表明其所属具体 target/module 命中 `build_any`；
- 仓库其他位置出现 `Qt6` 等字符串不能作为所有 C++ 文件的构建证据；
- 每个匹配结果保留命中依据，无法确认归属时记为 `partial`，不编造匹配结果。

`.qmltypes` 默认只作为类型信息上下文，不直接套用完整 QML 界面规则；若要审查，必须另行声明适用检查项。

## 专项调用

专项至少接收：

```text
stackId
projectRoot
scopeMode
matchedFiles
changedLines / revision 信息
guidance 内容及来源
匹配证据及必要上下文
```

专项不得重新猜测 diff、重新选择范围、扫描整个仓库或调用另一个专项。`enabled: false` 不调用；启用但无匹配文件为 `not-applicable`。框架模式保留上游用户确认，不自动开启。

## 专项结果

专项结果至少包含：

```text
stackId
status: complete / partial / failed / not-applicable / disabled
scope
executedChecks
skippedChecks / limitations
findings
investigationTargets
rawReportPath（没有落盘时为空）
```

每个发现至少保留来源 Skill、原始编号、规则 ID（若有）、文件位置、问题及证据、建议、严重度及理由；置信度只有来源提供时填写。置信度与严重度独立，待人工确认项不能自动升级为确认缺陷。

Python 缺失、必要 lint 无法执行或必要分析未完成时为 `partial`；`qmllint` 缺失只记录为可选检查未执行，不单独导致失败。工具诊断退出与崩溃、超时、参数错误分开记录。

## 汇总和结论

统一报告包含 `genericReview`、`specialists.<stack-id>`、配置状态、覆盖限制和 `conclusion`。同文件、同位置、同问题语义才去重，并保留所有来源。

结论优先级固定为：

```text
确认的阻断问题       → REQUEST_CHANGES
无阻断但阶段未完成   → INCOMPLETE
必要阶段全部完成     → APPROVE
```

`INCOMPLETE` 不是通过，不能被下游合入或归档流程当作已完成。审查不修改业务代码、配置、Skill 或经验库。
