# 安装、启用与验证

## 安装与启用是两步

1. 安装资源：Windows 使用 `setup.bat <项目目录> claudecode` 或 `opencode`；macOS/Linux 使用 `./setup.sh <项目目录> claudecode` 或 `opencode`。每个 `skills/<name>/SKILL.md` 是独立 Skill，整个 EdanSpec 仓库不是一个 Skill。Qt Skill 与通用 Skill 平铺安装。
2. 项目维护者显式启用：将本 Skill 的 `examples/review-stack.yaml` 复制或合并到项目 `.edan-dev/review-stack.yaml`，将 guidance 示例放到 `.edan-dev/review-notes/`，填写实际 Qt 版本、target 和 imports。已有 `AGENTS.md`、自定义配置和 Skill 不覆盖。

配置缺失时 `edanspec-code-review` 只做通用四维审查；它不会自动创建配置或下载规则。安装成功只说明资源已复制，不代表宿主已经发现或调用 Skill。

## 依赖边界

| 层 | 要求与缺失行为 |
|---|---|
| 宿主 | 提供 Skill 加载、文件/命令访问和模型调用；专项由宿主按配置直接调用 |
| 模型服务 | 深度分析使用宿主已配置的服务 |
| Python | Qt 专项运行上游 lint 时需要；缺失或必要 lint 失败记为 `partial` |
| Git | diff/commit 审查需要；directory 审查不要求 Git |
| Qt 工具 | `qmllint` 可选；必须记录实际版本、参数和 imports |
| CodeGraph | 只有已有 `.codegraph/` 时按项目约定查询；没有则搜索，不自动建立索引 |

Qt 规则和 lint 随 Skill 分发，内网运行不临时联网下载。来源、版本和许可见各专项的 `UPSTREAM.json` 与 `LICENSE.txt`。Qt 5、版本未知或规则不适用时必须披露覆盖限制。

## 宿主验证

从目标宿主启动 `/edanspec-code-review`，输入明确的审查基准。验证通用 reviewer 先执行，并在配置启用且匹配时由父入口直接调用对应 Qt Skill；两个专项共用固定范围但不互相调用。结果应包含匹配依据、执行检查、跳过项、限制、发现和结论。

至少验证：无配置、禁用项、纯 C++、Qt C++、QML、混合仓库、删除/重命名/空格路径、配置错误、guidance 缺失、必要 lint 失败，以及 `qmllint` 缺失。确认 `INCOMPLETE` 不会被下游当作通过。未实际验证的平台单独记录，不能由安装成功推断宿主可用。
