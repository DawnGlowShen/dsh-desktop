# 状态推导规则

本文件是**任务进度**与**审查关卡状态**的唯一判定依据。全部从文件事实推导，**不需要任何脚本或解释器**——用读文件即可核对，离线/内网环境同样可用。

## 一、任务状态（tasks.md）

### 解析规则

| 字段 | 识别方式 |
|------|---------|
| 任务标题 | 行首 `### Task-NNN：标题`（半角 `:` 或全角 `：` 均可） |
| 前置依赖 | `**前置依赖**：Task-001，Task-002`；值为 `无` / `none` / 空 → 无依赖。分隔符支持 `，` `,` `;` `；` |
| 涉及文件 | `**涉及文件**：` 之后的 `- ` 列表项；每项取第一个空格前的路径，去掉反引号 |
| 增量 | `- [ ] **增量 N**：描述` 或 `- [x] **增量 N**：描述` |

任务正文范围：从本任务标题到下一个 `### Task-` 标题（或文件结尾）。

### 状态计算

按 tasks.md 中的**出现顺序**逐项计算；**已判为 done 的任务计入「依赖已满足」集合**：

| 条件 | 状态 |
|------|------|
| 增量数 > 0 且全部为 `[x]` | `done` |
| 已完成增量数 > 0 但未全部完成 | `in_progress` |
| 增量完成数为 0，且前置依赖全部 done | `ready` |
| 其余 | `pending` |

> 没有写任何「增量」checkbox 的任务**永远不会变成 `done`**。每个任务至少要有增量。

**断点** = 第一个状态不为 `done` 的任务（按出现顺序）。

## 二、审查关卡状态

三个关卡各对应 feature 目录下的一个报告文件：

| 关卡 | 报告文件 |
|------|---------|
| code-review | `code-review-report.md` |
| security-review | `security-review-report.md` |
| verify | `verify-report.md` |

### 单个报告判定

1. 文件不存在 → `pending`
2. 文件存在：扫描严重度表格行的数字，缺失按 0 计 —— `| CRITICAL | N |`、`| IMPORTANT | N |`、`| SUGGESTION | N |`
3. 找结论行 `| **结论** | APPROVE / REQUEST_CHANGES / INCOMPLETE |`
   - `APPROVE` → `passed`
   - `REQUEST_CHANGES` → `failed`
   - `INCOMPLETE` → `incomplete`
   - 无结论行时：CRITICAL = 0 → `passed`，否则 `failed`
4. `hasCritical` = CRITICAL 数 > 0

### 全部通过

`allPassed` = 三个关卡状态均为 `passed` **且** `hasCritical` 均为 false。

`incomplete` 一律视为未通过——报告结构不完整、检查未跑完、配置错误都归此类，不允许当作通过。
