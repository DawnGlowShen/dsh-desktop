---
name: edanspec-task-implement
description: 依据任务文档执行代码实现。增量式开发 + 测试驱动（TDD），每个增量独立验证后原子提交。触发场景：用户要求开始实现功能或修复 bug、按任务计划执行、继续上次工作。不适用于纯配置变更、文档更新、简单重命名。小改动（≤2 文件）走 SLIM 档——不建完整方案文档，但验证证据不可省。
---

<!-- STATE_RULES: references/state-derivation.md（相对本 SKILL.md 所在目录）。任务与审查状态全部由该文件的规则从文件事实推导，不依赖任何脚本或解释器，离线/内网环境同样可用 -->

# 任务实现

把任务变成代码。核心原则：**增量开发 + TDD + 原子提交**。

> 概念：**任务**是 plan 阶段的规划单元，**增量**是 implement 阶段的执行单元。一个任务包含一个或多个增量，每个增量独立完成一条验收标准。

```
判定档位（SLIM / STD / FULL，见步骤零）
  ↓
恢复（从 tasks.md 事实驱动，按状态推导规则计算断点）
  ↓
加载（读 tasks.md → 检查依赖 → 判定串行/并行）
  ↓
准备（检测环境命令 → 加载规范 → 内联计划）
  ↓
执行（串行 TDD 循环 或 并行 SubAgent + worktree）
  ↓
提交 + 更新（原子提交 → checkbox）
  ↓
审查关卡（按档位：SLIM 自检 / STD 一次合并审查 / FULL 三关卡全过）
```

## 状态模型

任务状态以 `tasks.md` checkbox 为唯一事实来源。**按 `references/state-derivation.md` 的规则从 tasks.md 实时推导，不缓存、不写入任何文件、不需要脚本。**

**状态流转：**

```
pending ──(依赖全done)──→ ready ──(开始执行)──→ in_progress ──(全部增量完成)──→ done
  ↑                                                                                       │
  └────────────────────(回退/修复)────────────────────────────────────────────────────────┘
```

| 状态 | 含义 |
|------|------|
| `pending` | 初始状态，或依赖未满足 |
| `ready` | 前置依赖任务全部为 done |
| `in_progress` | 有部分增量完成但未全部完成 |
| `done` | 该任务的所有增量 checkbox 均为 `[x]` |

每次提交后**必须重新推导**所有任务状态，不要缓存。精确判定规则（含无增量任务永不 done 等边界）见 `references/state-derivation.md`。

---

## 步骤零：判定执行档位

**先判档，再动手。** 进入实现前一次性判定，并在回复中亮出结论（一两行即可，用户一句话就能改档）。

| 档 | 判定条件（需全部满足） | 审查关卡 | 文书成本 |
|---|---|---|---|
| **SLIM** | 改动 ≤2 文件 且 ≤50 行；不改接口/契约/依赖/schema/配置项；不触安全敏感面；非破坏性 | 无独立关卡，改为一次自检（6.6） | 仅 `change.md` |
| **STD** | ≤7 文件；单模块；无架构变更、无新依赖、无 schema / 安全模型变更 | 一次合并审查（6.7） | proposal + specs + design + tasks.md |
| **FULL** | 其余全部情况：≥8 文件 / 跨模块 / 架构变更 / 新第三方依赖 / schema 变更 / 安全模型变更 / 破坏性变更 | 三关卡全过（6.1–6.5） | 现有全部 |

**判定优先级**：用户显式指定 > 上表自动判定。用户说「走完整流程」→ FULL；说「小改一下」→ 倾向 SLIM。

**升级闸门（必须执行）**：实现过程中实际改动超出本档条件（文件数/行数超限，或碰到接口、依赖、schema、安全面）→ **立即停下**，告知用户实际范围，升级档位，补齐该档要求的产物与关卡。**不得以 SLIM 之名继续推进。**

**不可裁剪项（三档通用，任何档位都不省）：**

- **改动必须有证据** — 至少跑通相关测试或构建，SLIM 也不例外。「看起来对」不是证据
- **安全红线必查** — 涉及用户输入、认证授权、密钥凭证、SQL、文件上传、外部请求时，无论哪档都做安全自查
- **范围纪律与原子提交** — 只改分内文件，`git add` 指定文件
- **破坏性变更需授权** — 数据库、API、配置、CI/CD 变更必须用户明确同意

**可裁剪项**：方案文档厚度、审查关卡的独立性（合并为一次 subagent vs 三个独立 subagent）、确认点数量、覆盖率检查（仅项目已配置时执行）。

> 这条划线的理由见 `AGENTS.md` 与 `docs/anti-patterns.md` 的「轻量化 ≠ 跳过验证」。省的是**文书成本**，不是**证据成本**。

---

## 步骤一：恢复

有活跃 feature 时自动执行，从状态驱动恢复，不依赖会话记忆。

**检测流程**：`EdanSpec/feature/` 下有活跃工单 → 按 `references/state-derivation.md` 推导任务状态 → 从第一个状态不为 `done` 的任务恢复；无活跃工单 → 继续步骤二。

**恢复操作**：
1. `find EdanSpec/feature/ -maxdepth 1 -mindepth 1 -type d | sort` 定位工单
2. 读 `<feature-dir>/tasks.md`，按 `references/state-derivation.md` 解析任务与增量 checkbox，推导每个任务状态
3. 找出第一个状态不为 `done` 的任务 → 断点
4. 如果全部 done → 按 `references/state-derivation.md` 推导审查关卡状态，见步骤六
5. 如果 tasks.md 无任务 → 确认是否需要调用 task-plan
6. `git log --oneline -10` + `git status` 确认分支和提交状态
7. 跑一次测试确认代码正常

| 场景 | 操作 |
|------|------|
| 任务全部 done，审查关卡全部 passed | 引导进入 archive |
| 任务全部 done，审查关卡有 pending/failed | 从第一个 pending/failed 关卡继续（步骤六） |
| 部分任务 in_progress | 从该任务的第一个未完成增量继续 |
| 有 ready 但未开始 | 从第一个 ready 任务开始 |
| tasks.md 无任务/缺失 | 无任务可执行，确认是否需要调用 task-plan |
| 无 tasks.md 但存在 `change.md` | SLIM 档工单 → 直接进入实现（无任务拆分） |
| 测试失败 | 调 `edanspec-debugging` 排障 |

**事实来源**：任务状态与审查状态都从文件事实实时推导，**不持久化到任何文件、不需要脚本**——规则见 `references/state-derivation.md`。报告文件不存在即视为 pending。

**警示信号**：不检查 git 状态就继续、checkbox 与 git 提交不一致却不修正、推导出的状态与 tasks.md 不一致时不重新推导。

---

## 步骤二：加载

读取 `EdanSpec/feature/<name>/tasks.md`，记录验收标准、涉及文件、任务依赖关系。

> SLIM 档：无 tasks.md，跳过本步骤，直接进入步骤三。

### 依赖检查

前置未完成 → 停下来先完成依赖。

| 依赖类型 | 检查方法 |
|---------|---------|
| 同 feature 内 | 对应增量 checkbox 为 `[x]` |
| 跨 feature | 读目标 feature 的 tasks.md，按 `references/state-derivation.md` 确认其所有任务为 `done` |

### 并行判定

**并行组解析**：从 tasks.md 中解析并行关系：
1. 扫描 `<!-- PARALLEL: Task-XXX, Task-YYY -->` 注释，提取并行组
2. 验证并行条件：两个任务可并行当且仅当：
   - 并行组注释中明确列出，且
   - 两者的"涉及的文件"列表无交集，且
   - 前置依赖任务均已完成（增量 checkbox 全 `[x]`）
3. 确定并行组后，向用户报告并确认

**并行执行前置条件**（必须全部满足）：
- 并行任务的**前置依赖任务已全部完成**（增量 checkbox 全 `[x]`）
- 项目已有**基础骨架**（初始化/构建配置已完成，worktree 中可正常编译）
- 两者的文件修改无交集

全部满足 → 标记并行组，走步骤三并行路径。任一不满足 → 串行，走步骤三串行路径，并向用户说明原因。

> SLIM 档默认串行——单文件小改动没有并行收益。

### 冲突检测

创建 feature 时做过一次冲突检测，但实现阶段可能有新 feature 创建并修改同一 capability。开始编码前再检查一次：

1. 读 `status.json` 的 `conflicts` 字段，确认是否有预记录的冲突
2. 扫描当前 feature 涉及的所有 capability（从 `specs/` 目录或 `design.md` 提取）
3. 检查其他活跃 feature 是否也在修改同一 capability
4. 发现新增冲突 → 提醒用户："当前 feature 与 `{other-features}` 均修改了 `{capability}`，建议确认分工"

冲突不阻塞实现，但必须在归档前解决。

---

## 步骤三：准备

### 检测环境

确定测试、构建、lint 命令。详见 `references/environment-detection.md`。后续所有增量统一使用这组命令。

**确认覆盖率工具状态：**

| 档位 / 场景 | 操作 |
|------|------|
| FULL / STD + 全新项目初始化 | 初始化工程时同步配置覆盖率工具（如 JaCoCo、pytest-cov、Vitest coverage），不得留到后面补 |
| FULL / STD + 已有项目未配置 | 在 `tasks.md` 中增加「配置覆盖率工具」任务，编码前先完成 |
| **SLIM** | 项目已有覆盖率工具则运行；**没有则不为此新建配置**——小改动配一套工具的收益低于其成本。但测试或构建证据不可省 |

覆盖率报告必须能在构建或测试命令中一键生成，见 `references/coverage-check.md`。

### 加载规范

按 `AGENT.md` 映射表加载 `rules/` 下对应规范。spawn 子 Agent 时拼入 prompt。

### 内联计划

编码前用一两行说明思路，让用户有机会纠偏：
```
Plan:
1. 编写 createTask 的失败测试
2. 实现最小版本让测试通过
3. 重构：提取 id 生成逻辑
→ 开始执行，除非你另有指示。
```

---

## 步骤四：执行

### TDD 循环（串行 + 并行通用）

```
RED（失败测试）→ GREEN（最小实现）→ REFACTOR（重构）→ 验证 → 提交
```

测试必须先写且先失败。实现刚好满足测试通过即可。编写测试前读 `references/tdd-principles.md`。

### 验证规则

每个增量提交前必须通过以下验证：

| # | 验证项 | SLIM | STD / FULL |
|---|--------|------|-----------|
| 1 | **测试通过** — 该增量涉及的测试文件全部通过 | 必须 | 必须 |
| 2 | **构建成功** — 项目可编译 | 必须 | 必须 |
| 3 | **Lint 通过** — 代码风格无违规 | 项目已配置则跑 | 必须 |
| 4 | **类型检查通过** — 无类型错误 | 项目已配置则跑 | 必须 |
| 5 | **覆盖率达标** — 运行覆盖率工具检测，新增/修改文件达到基线要求（详见 `references/coverage-check.md`） | 项目已配置则跑 | 必须 |

> 覆盖率不得推算，必须实际运行覆盖率工具检测。SLIM 档放宽的是「为没有覆盖率工具的项目新建一套配置」，不是「编造覆盖率数字」。

**验证分类**：

| 类型 | 执行方式 |
|------|---------|
| 自动化验证 | Agent 自动执行命令 |
| 手动验证（模拟器操作、UI 视觉检查、完整流程走查） | **跳过，不执行**。Agent 仅执行自动化验证 |

**规则**：
- 自动化验证不通过 → 调 `edanspec-debugging` 排障，不得跳过
- 所有验证均为 Agent 可自动执行的命令验证，无需用户手动确认
- 测试失败 → 调 `edanspec-debugging` 五步排障，不盲目改代码

### 串行路径

每个任务按顺序执行 TDD 循环，每个增量完成后立即提交（见步骤五）。

### 并行路径

详见 `references/parallel-execution.md`。

---

## 步骤五：提交与状态更新

### 原子提交

提交消息格式：
```
feat: 实现任务创建功能

- 新增 createTask 函数
- 完成 Task-001 增量 1, 2

Co-Authored-By: Claude
```

- `git add` 指定文件（禁止 `-A`）
- 提交前 `git status` 确认无无关变更

### 更新状态

增量完成后立即更新，不等全部完成。

| 操作 | 时机 |
|------|------|
| 增量验证通过 → 对应增量改为 `[x]` | 增量验证通过后 |
| 提交后按 `references/state-derivation.md` 重新推导任务状态 | 每次提交后 |

每次提交后**必须重新推导**任务状态，不要缓存（SLIM 档无 tasks.md，此步跳过）。

### 执行循环

每个增量的完整流程是一个循环：

```
执行 TDD → 验证 → 原子提交 → 更新状态 → 下一个增量
```

循环终止条件：tasks.md 中所有任务的增量 checkbox 均为 `[x]` → 进入步骤六（审查关卡）。SLIM 档：改动完成且验证通过 → 进入 6.6。

---

## 步骤六：完成后审查关卡

**关卡按档位执行**，先一览全貌：

| 档 | 关卡 | 位置 |
|---|---|---|
| SLIM | 实现后自检（写进 `change.md`） | 6.6 |
| STD | 一次合并审查（产出三份报告） | 6.7 |
| FULL | 三关卡独立执行，全部必须通过 | 6.1–6.5 |

无论哪档，**任一关卡未执行或未通过 → 不算实现完成**。

---

### FULL 档：三关卡独立执行

tasks.md 中所有任务完成后，**必须通过三个审查关卡**，全部通过后才算实现完成。

```
tasks.md 全部 done
  ↓
按 references/state-derivation.md 基于报告文件事实推导审查状态
  ↓
基于报告文件状态选择下一个 pending/failed 关卡执行
  ├─ code-review（代码审查，四维度）→ 写入 code-review-report.md
  ├─ security-review（安全审查，五维度）→ 写入 security-review-report.md
  └─ verify（三维度验证）→ 写入 verify-report.md
  ↓
allPassed = true → 实现完成，引导归档
```

三个关卡**推荐按 code-review → security-review → verify 顺序执行**，恢复时从任意 pending/failed 关卡继续，已通过的直接跳过。

#### 6.1 恢复断点

**审查状态以报告文件为事实来源。** 按 `references/state-derivation.md` 的规则读取 feature 目录下的 `code-review-report.md`、`security-review-report.md`、`verify-report.md` 并解析结论与严重度。

| 审查状态 | 操作 |
|---------|------|
| `allPassed = true` | 引导进入 archive |
| 任一关卡 `hasCritical = true` | 自动修复该关卡所有 CRITICAL 问题，修复后删除对应报告文件，重新执行该关卡 |
| 有 pending 关卡 | 执行第一个 pending 关卡（按 code-review → security-review → verify 顺序） |
| 有 passed 关卡 | **直接跳过**，不重复执行。即使 code-review 中已引导过 security-review，仍以报告文件状态为准 |

> **关于重复审查**：code-review 可能识别到安全问题并引导用户单独执行 `edanspec-security-review`。此时 security-review-report.md 可能已存在且状态为 passed。步骤六不再重复执行，直接跳过已通过的关卡。

#### 6.2 执行 code-review

调用 `edanspec-code-review` 对当前 feature 的代码变更进行四维度审查。审查完成后报告必须写入 `{feature-dir}/code-review-report.md`。

- **有 CRITICAL** → 展示报告，**自动修复**所有 CRITICAL 问题，修复后删除 `code-review-report.md`，重新执行 code-review
- **无 CRITICAL 且结论 APPROVE、必要阶段完整** → 报告写入 `code-review-report.md`，继续下一阶段
- **INCOMPLETE / 配置错误 / 必要阶段未完成 / 报告损坏** → 不通过，补全并重新审查；不能只凭 CRITICAL=0 放行

#### 6.3 执行 security-review

调用 `edanspec-security-review` 对当前 feature 的代码变更进行五维度安全审查。审查完成后报告必须写入 `{feature-dir}/security-review-report.md`。

- **有 CRITICAL** → 展示报告，**自动修复**所有 CRITICAL 问题，修复后删除 `security-review-report.md`，重新执行 security-review
- **无 CRITICAL** → 报告写入 `security-review-report.md`，继续下一阶段

#### 6.4 执行 verify

调用 `edanspec-verify` 对当前 feature 执行三维度验证。verify 通过 task 工具启动通用代理在独立子进程中执行。验证完成后报告必须写入 `{feature-dir}/verify-report.md`。

- **有 CRITICAL** → 展示报告，**自动修复**所有 CRITICAL 问题，修复后删除 `verify-report.md`，重新执行 verify
- **无 CRITICAL** → 报告写入 `verify-report.md`，实现完成

#### 6.5 审查完成判定

> 本节适用于产出报告文件的 **STD / FULL 档**；SLIM 档没有报告文件，其通过判定见 6.6。

按 `references/state-derivation.md` 确认 `allPassed = true` → 更新 `status.json`：`state = "completed"`，然后提示用户归档：

使用 **AskUserQuestion 工具**让用户决定：

> "实现完成，全部审查通过。要现在归档这个 feature 吗？归档会合并 Delta Spec 到主规格并清理 feature 目录。"

| 用户选择 | 操作 |
|---------|------|
| 是，归档 | 引导调用 `edanspec-archive` |
| 暂不归档 | 接受，但告知风险："Delta Spec 未合并，后续新 feature 可能产生冲突误判。下次会话可用 `create-spec` 启动检测提醒归档。" |

---

### 6.6 SLIM 档：实现后自检（替代三关卡）

SLIM 档不启动独立审查 subagent，但**必须逐项自检并把结论写进 `change.md` 的「验证」段**：

1. **证据** — 跑通相关测试或构建，记录**实际命令与结果**。不得写"看起来没问题"
2. **安全自查**（涉及用户输入 / 认证 / 密钥 / SQL / 文件上传 / 外部请求时必做）：
   - 输入是否校验？是否直接拼接进 SQL、命令或文件路径？
   - 是否引入硬编码密钥或凭证？
   - 日志或响应中是否包含敏感数据？
   - 权限判断是否在服务端而非仅前端？
3. **范围自查** — `git diff --stat` 确认改动文件数与规模符合 SLIM 条件，未触碰无关文件
4. 任一项不通过 → 修复后重跑；修复超过 2 次未成功 → 停止并报告（见「验证与引导」的修复上限）

**自检中若发现实际改动超出 SLIM 条件**（文件数/行数超限，或触及接口、依赖、schema、安全面）→ **升级档位**，补齐 STD/FULL 要求的产物与审查关卡。

自检通过 → 更新 `status.json` 的 `state = "completed"` → 按 6.5 的**用户选择表**提示归档（SLIM 档无报告文件，不适用 6.5 的 `allPassed` 判定）。

---

### 6.7 STD 档：一次合并审查（替代三次独立调用）

STD 档用**一次 subagent 调用**同时完成三个维度，**产出三份报告文件**——这样归档检查逻辑与 FULL 档完全一致，无需区分档位。

- 同一次调用中，依次依据 `edanspec-code-review` 四维度、`edanspec-security-review` 五维度、`edanspec-verify` 三维度的检查清单通读变更
- 分别产出 `code-review-report.md`、`security-review-report.md`、`verify-report.md`，**格式与 FULL 档一致**（三态结论 APPROVE / REQUEST_CHANGES / INCOMPLETE + 严重度统计表）
- 任一维度有 CRITICAL → 展示并自动修复 → 删除对应报告 → 重新执行该维度
- 三个维度全部 passed 且无 CRITICAL → 进入 6.5

> 省掉的是**三次独立 subagent 的上下文开销与三次往返确认**，不是审查维度本身——三个维度的检查项一项不少。

---

## 实现规则

| 规则 | 内容 |
|------|------|
| 0 — 简单优先 | 三行重复优于过早抽象 |
| 1 — 范围纪律 | 只改任务涉及的文件，不"顺手" |
| 2 — 单一关注 | 每个增量只做一件事 |
| 3 — 持续可构建 | 每个增量后项目可编译、测试全绿 |
| 4 — Feature Flag | 未完成功能用环境变量隐藏入口 |
| 5 — 可回滚 | 每个增量可独立回退 |
| 6 — 验证必执行 | 每个增量必须通过自动化验证，不可跳过。SLIM 档也不得只凭主观判断 |
| 7 — 并行有界 | 仅无文件重叠且无依赖时并行，合并后统一验证 |
| 8 — 及时更新 | 任务完成后立即更新 tasks.md checkbox 并重新推导状态（SLIM 档无 tasks.md，跳过） |
| 9 — 覆盖率必检 | 每个增量完成后必须运行覆盖率工具检测并记录数值，不得推算。SLIM 档且项目未配置覆盖率工具时，以测试或构建证据代替 |
| 10 — 审查必过 | 全部任务完成后必须过审查关卡：FULL 三关卡全过、STD 一次合并审查三份报告全过、SLIM 完成自检并写入 change.md。缺一不算完成 |
| 11 — 档位诚实 | 发现实际改动超出所判档位条件时立即升级档位，不硬撑 |

---

## 常见误区与反驳

> 通用误区见 `AGENT.md`。

| 说辞 | 真相 |
|------|------|
| "顺便重构一下这段代码" | 范围纪律。与任务无关的代码不动 |
| "文档里没提到但应该加上" | 不添加规范外的功能，需回到任务文档更新 |
| "就改两行，不用测了吧" | 小改动最难回滚、最易漏测。SLIM 省的是文档，不是验证 |
| "判定成 SLIM 了，安全那块就不用看了" | 安全红线不分档位。碰到用户输入/认证/密钥/SQL/上传一律要查 |

## 需要警惕

- 超过 100 行代码未执行测试
- 单个增量包含多个无关联改动
- 跳过测试/验证
- **跳过覆盖率检查或凭感觉判断**（必须运行工具检测；SLIM 档项目未配置覆盖率工具时以测试或构建证据代替）
- 修改任务范围之外的文件
- 只更新增量 checkbox，未重新推导任务状态
- 任务完成不及时重新推导状态，恢复时状态不一致
- 推导出的状态与 tasks.md checkbox 不一致时不重新推导
- 并行条件不满足时强行并行（项目骨架未完成、文件有交集）
- 覆盖率报告未记录实际数值就提交
- **跳过审查关卡直接归档**（按档位：FULL 三关卡必须全部通过、STD 三份报告全过、SLIM 自检完成并写入 change.md；已通过的不重复执行）
- 报告文件显示有 CRITICAL 时未修复就进入下一阶段
- **实际改动已超出所判档位条件，却仍按 SLIM 推进**

## 验证与引导

**单个任务完成**：所有增量 checkbox 全 `[x]`、测试全通过、已提交、状态已重新推导。

**全部任务完成**：全量测试通过、构建产物干净、工作区无未提交变更、审查关卡按档位全部通过。

**修复上限提醒**（详见 `edanspec-debugging`）：修复次数从尝试次数计数——同一问题修复超过 2 次未成功应停下来重新定位根因（第 3 次，调 `edanspec-debugging`）；超过 3 次应调 `edanspec-explore` 重新审视设计方案（第 4 次）；第 5 次停止并报告问题。

## 辅助资源（按需加载）

- `references/state-derivation.md` — 任务状态与审查关卡状态的判定规则（无脚本，离线可用）
- `references/tdd-principles.md` — TDD 循环与测试编写原则
- `references/coverage-check.md` — 覆盖率检查流程与基线标准
- `references/parallel-execution.md` — 并行执行流程与 task prompt 模板
- `references/environment-detection.md` — 构建/测试/lint 命令检测
- `references/slicing-strategies.md` — 任务拆分策略
