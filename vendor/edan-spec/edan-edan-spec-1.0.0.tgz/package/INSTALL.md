# @edan/edan-spec 本地分发安装说明

本插件包（目录 `edan-spec-plugin`）通过 `file:` 路径本地安装进 DSH profile，无需发布到 npm。

## 前置条件

- 目标机器已安装 DSH（桌面版或 CLI 版）。
- 已确定要安装到的 **profile 名**（桌面 GUI 通常为 `web`，CLI 用户也可能是 `headless`/`tui` 等，按实际填 `<profile>`）。
- 关闭 DSH Desktop 应用（安装会改动 profile 的依赖，建议先退出再装）。

## 一、确认 dsh CLI 可用

**场景 A：机器有全局 `dsh` 命令**（CLI 安装版）

```bash
dsh --version
```

**场景 B：机器只有 DSH Desktop（无全局 dsh，最常见）**

使用应用内置的 CLI。macOS 路径：

```bash
BIN="/Applications/DSH Desktop.app/Contents/Resources/app/node_modules/@deepseek-ai/dsh/lib/bin.js"
```

Windows 的安装路径可能不同，请按实际应用安装位置定位 `node_modules/@deepseek-ai/dsh/lib/bin.js`。

> 提示：可先设一个别名方便后续使用：
> ```bash
> alias dsh="node \"$BIN\""
> ```

## 二、安装

把整个 `edan-spec-plugin` 目录拷贝到目标机器后，在任意目录执行：

```bash
# 场景 A（有全局 dsh）
dsh plugin --profile <profile> add file:/绝对/路径/edan-spec-plugin

# 场景 B（只有桌面应用）
node "/Applications/DSH Desktop.app/Contents/Resources/app/node_modules/@deepseek-ai/dsh/lib/bin.js" plugin --profile web add file:/绝对/路径/edan-spec-plugin
```

示例（web profile）：

```bash
dsh plugin --profile web add file:/Users/xxx/Downloads/edan-spec-plugin
```

安装成功后：
- 插件会加入 profile 的 `dependencies`
- 因包声明了 `dsh.bundle.patch`，会自动注册进 `dsh.profile.bundles`（成为 profile 层）
- 重启 DSH Desktop 后生效

## 三、验证

1. **重启 DSH Desktop**。
2. 发起任意对话，AI 应能看到 11 个 `edanspec-*` 技能（`edanspec-create-spec`、`edanspec-task-plan`、`edanspec-verify` 等）。
3. 会话的 workspace instructions 中应出现 `Instructions from: @edan/edan-spec/AGENTS.md`。
4. 项目根的 AGENTS.md 照常加载，两者并存不冲突。
5. 注入的 AGENTS.md 中 `docs/`、`rules/` 引用会被重写为包内绝对路径（如 `…/@edan/edan-spec/docs/git-conventions.md`），模型可直接读取随包分发的规范文件。

> **更新已安装副本**：本包通过 `file:` 安装时是复制进 profile（非符号链接）。源码改动后需重新执行一次 `add` 同步新内容，再重启生效。

## 四、卸载 / 重新安装

```bash
# 卸载
dsh plugin --profile <profile> remove @edan/edan-spec

# 重新安装（更新本地目录内容后）
dsh plugin --profile <profile> add file:/绝对/路径/edan-spec-plugin
```

## 常见问题

**Q: 启动报 `--expose-internals is required for HMR service`？**
这是命令行裸启动造成的，DSH Desktop 正常启动会带此参数，不影响。直接用 GUI 打开即可。

**Q: 启动报 task-board 相关锁错误？**
通常是旧进程残留。完全退出 DSH Desktop 后重启；若仍报错，可删除残留锁文件（在 harness 的 `task-board/` 目录下的 `*.lock`）。

**Q: 技能没出现？**
确认 `add` 成功、`dsh.profile.bundles` 里已有 `@edan/edan-spec`，然后完全退出并重新打开 DSH Desktop（不是刷新窗口）。
