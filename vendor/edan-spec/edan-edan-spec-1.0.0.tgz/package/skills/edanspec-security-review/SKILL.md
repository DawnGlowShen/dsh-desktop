---
name: edanspec-security-review
description: 合入前安全审查——输入验证、认证/授权、数据保护、机密管理、依赖漏洞。触发场景：涉及用户输入、认证/授权、数据存储、外部集成、文件上传的代码变更，用户要求「安全检查」「审查安全性」「安全漏洞」「跨站脚本」「SQL 注入」。不适用于纯 UI 样式调整或文档变更。
---

# 安全审查

合入前系统性地审查安全风险。**安全不是事后补丁——每一行接触用户数据、认证、外部系统的代码都必须经过审查。**

> **职责分工**：本 skill 负责流程编排（确定范围 → 启动审查 → 处理结果）。审查维度定义、检查项细则、输出格式以 `security-reviewer-agent.md` 为准。

## 流程

### 1. 确定范围

理解变更意图：实现什么功能？涉及哪些模块？是否接触用户输入/认证/敏感数据？

超过 200 行的变更很难发现所有安全问题——建议拆分，先审查核心模块。

### 2. 启动 Security Reviewer Subagent

读取 `security-reviewer-agent.md` 全文，拼上本次审查上下文（变更范围、项目类型、语言），
通过**当前平台的 subagent 机制**传给通用代理执行。

**平台适配：**

| 平台 | 调用写法 |
|------|---------|
| Claude Code | `Agent tool`（通用代理），prompt = 文件全文 + 上下文 |
| OpenCode | `task({ subagent_type: "general", prompt: 文件全文 + 上下文 })` |

**上下文隔离**：独立子进程执行，保证审查的专业性和独立性。

### 3. 处理结果

| 级别 | 含义 | 处理 |
|------|------|------|
| **CRITICAL** | 可被利用的漏洞（SQL注入、硬编码密钥、明文密码） | 必须修复才能合并 |
| **IMPORTANT** | 潜在风险（缺少授权检查、敏感日志、无速率限制） | 应该修复再合并 |
| **SUGGESTION** | 安全加固建议（加密升级、CSP 收紧） | 可以考虑 |

**有 CRITICAL → 不批准合并。**

## 报告持久化

审查完成后，**必须将报告写入文件**，以便 task-implement 步骤六基于事实检查。

| 条件 | 操作 |
|------|------|
| 在 feature 目录下（存在 `EdanSpec/feature/` 路径） | 将报告写入 `{feature-dir}/security-review-report.md`，并输出报告到控制台 |
| 不在 feature 目录下 | 仅输出报告到控制台，不写文件 |

**判定规则：**
- 有 CRITICAL → 报告结论为 `REQUEST_CHANGES`，`security-review-report.md` 中 CRITICAL 数量 > 0
- 无 CRITICAL → 报告结论为 `APPROVE`，`security-review-report.md` 中 CRITICAL 数量为 0

**报告文件路径**：`{feature-dir}/security-review-report.md`。task-implement 恢复时通过读取此文件判断是否已通过。

## 常见误区与反驳

> 通用误区见 `AGENT.md`。

| 说辞 | 真相 |
|------|------|
| "框架会处理安全" | 框架提供工具，不是保证。你仍需正确使用它们 |
| "这个端点只是测试用的" | 测试端点上线后被遗忘 = 最大的后门 |

## 警示信号

- 用户输入直接传递给数据库查询、shell 命令或 HTML 渲染
- 源码或 git 历史中有密钥
- API 端点缺少认证或授权检查
- CORS 配置为通配符 `*`
- 认证端点无速率限制
- 错误消息暴露堆栈跟踪或内部路径

## 验证

- [ ] 五维度均已审查
- [ ] 无 CRITICAL 问题遗留
- [ ] 每个发现都有文件位置和修复建议
- [ ] 审查结论与问题级别一致（有 CRITICAL = REQUEST CHANGES）
