# @edan/edan-spec

将 EdanSpec 工作流（方案 → 规划 → 实现 → 审查 → 验证 → 归档）打包成 DSH 插件，随 profile 分发。

## 内容

- **skills/** — 11 个技能（真实文件，保留 `references/`、`scripts/` 及跨技能相对引用）：
  `edanspec-create-spec`、`edanspec-task-plan`、`edanspec-task-implement`、`edanspec-code-review`、`edanspec-design-review`、`edanspec-security-review`、`edanspec-verify`、`edanspec-archive`、`edanspec-debugging`、`edanspec-explore`、`project-context`。
- **docs/** + **rules/** — AGENTS.md 引用的规范文件（`docs/git-conventions.md`、`docs/anti-patterns.md`、`rules/{common,java,kotlin}/`），随包分发。
- **AGENTS.md** — 随包分发，由插件**持久注入**为每个会话的全局基线指令（见下）。

### AGENTS.md 引用文件的可达性

注入的 AGENTS.md 里对 `docs/`、`rules/` 的引用会在注入时**重写为包内绝对路径**（如 `…/node_modules/@edan/edan-spec/docs/git-conventions.md`）。这样无论当前工作项目在哪，模型读到引用都能直接 `read` 到随包分发的规范文件，而不依赖当前项目的目录。

## 机制

本包是一个 Cordis profile bundle：

1. `package.json` 声明 `dsh.bundle.patch` → `dsh plugin add` 后自动成为 profile 层。
2. `cordis.patch.yml` 作为组合补丁插入一个插件行（`@edan/edan-spec`）。
3. 插件 `apply()` 做两件事：
   - 复用 `@deepseek-ai/dsh-skill-filesystem`，以 `customSkillDirs`（rank 300）挂载包内 `skills/`，并设 `includeDefaultRoots: false` 使其只暴露本包技能。
   - 挂钩 `agent/pre-step`，把包内 `AGENTS.md` 作为**持久 user 消息**注入每个会话的基线。

技能以**真实文件**提供，因此 SKILL.md 正文中对 `references/`、`scripts/`（含 `../edanspec-task-implement/scripts/` 这类跨技能相对引用）全部保持有效。

### AGENTS.md 注入与项目根 AGENTS.md 不冲突的原因

DSH 内置的 `dsh-agent-instructions` 加载项目根/用户全局 `AGENTS.md`/`CLAUDE.md`，把它们放在 `source.kind === "agent-instructions"` 的 user 消息里，并只对**这种 source** 做去重/移除/替换。

本插件注入的 AGENTS.md 刻意使用不同的 source kind（`{ kind: "plugin", plugin: <name> }`），因此：

- `agent-instructions` 不会把这份内容当作自己的，不会去重、移除或替换它；
- 项目根的 AGENTS.md（项目专属）与本包的 AGENTS.md（全局方法论）作为两条独立的持久基线共存；
- 框架本身遵循「更具体指令优先于更宽泛指令」，项目规则自然叠加在全局规则之上。

去重：注入前会检查会话 surface 与待处理 inbox 是否已存在相同 content+source 的消息，避免重复注入（含 compaction/恢复场景）。

## 安装

详细安装/卸载/验证步骤见 [`INSTALL.md`](INSTALL.md)。摘要：

```bash
# 全局 dsh CLI 用户
dsh plugin --profile web add file:/绝对/路径/edan-spec-plugin

# 只有 DSH Desktop（无全局 dsh）——用应用内置 CLI
node "/Applications/DSH Desktop.app/Contents/Resources/app/node_modules/@deepseek-ai/dsh/lib/bin.js" \
  plugin --profile web add file:/绝对/路径/edan-spec-plugin
```

装完重启 DSH Desktop 生效。若包已发布到 npm：

```bash
dsh plugin --profile web add @edan/edan-spec
```

## AGENTS.md（随包持久注入）

AGENTS.md 随本包分发，由插件在**每个会话**持久注入为全局基线指令（source kind `plugin`，与项目根 AGENTS.md 不冲突、不互相去重）。安装本插件后无需再手动放置 AGENTS.md。

若某项目仍需项目专属的 AGENTS.md，直接放项目根即可，两者叠加生效。

## 发布

```bash
cd edan-spec-plugin
npm publish --access public
```

发布后即可通过 `dsh plugin add @edan/edan-spec` 安装。
