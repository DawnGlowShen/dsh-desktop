# 覆盖率检查

每个任务完成后，必须实际运行覆盖率工具检测，不得推算、估算或凭想象判断。

## 什么才算「单元测试」

**覆盖率只统计能脱离设备独立运行的测试。** 判定标准只有一条：**在没有目标设备的机器上（CI 容器、开发者本机）能否跑通**。

| 计入覆盖率 | 判定依据 | 典型形态 |
|-----------|---------|---------|
| ✅ 计入 | 纯 JVM / 进程内运行，无设备、无模拟器、无真机 | JUnit4 / JUnit5、Kotest、pytest、Vitest / Jest、Go `testing`、Rust `#[test]` |
| ❌ 不计入 | 需要设备或模拟器才能运行 | Android Instrumented Test（`androidTest/`、Espresso、UI Automator）、iOS XCTest UI Test、依赖真机的 HIL（硬件在环） |
| ❌ 不计入 | 需要真实数据库 / 外部服务连接 | 需启动 PostgreSQL / MySQL / Redis 的测试；调用真实外部 API 的测试 |
| ❌ 不计入 | UI 渲染、界面交互、截图比对 | Compose UI Test、Flutter `widgetTest` 中依赖渲染的用例、Selenium / Playwright 端到端 |

**分界不是「测试文件放在哪个目录」，而是「换一台干净的机器、不插设备、不连数据库，它还能不能跑」。** 依赖设备/数据库的部分**可以在项目里存在并被维护，但它们的通过与否不计入覆盖率数字，也不作为本流程的关卡证据**。

### 各平台的正确命令

覆盖率命令必须**只跑单元测试的 source set**，不要用会把设备测试一并拉起的命令：

| 平台 | ✅ 只跑单元测试 | ❌ 会带上设备/集成测试 |
|------|----------------|---------------------|
| Android / Gradle | `./gradlew testDebugUnitTest` + `testDebugUnitTestCoverage` | `./gradlew test` 在部分配置下会关联 `connectedAndroidTest`；`./gradlew check` 会跑仪器测试 |
| Android (KMP) | `./gradlew allTests` 中的 `jvmTest` 任务 | `connectedAndroidTest`、`iosSimulatorArm64Test` |
| Flutter | `flutter test`（纯 Dart VM 用例） | `flutter test integration_test/`、`flutter drive` |
| Node.js | `npx vitest run --coverage`（默认环境 node/jsdom） | 需浏览器或真实 DB 的用例 |
| Python | `pytest --cov=src`（不启动外部服务） | 需要 fixture 拉起真实 DB 的用例 |
| Go / Rust | `go test ./... -coverprofile=...` / `cargo test` | 需外部服务的集成用例（用 `-short` 或 build tag 排除） |

**如果项目未按此划分 source set**：先确认当前覆盖率命令实际跑了哪些测试；若它把设备测试也算进分母，**以能独立运行的那部分为准重新计算**，并在报告里写明口径（跑了什么命令、排除了什么）。不得用「设备测试也过了」来充当覆盖率证据。

### 报告里必须写明口径

覆盖率数值旁边要标出**跑了什么**，否则数字无法复核：

```
覆盖率报告（Task-XXX 完成）：
- 命令：./gradlew testDebugUnitTest testDebugUnitTestCoverage
- 范围：仅单元测试（不含 androidTest / connectedAndroidTest）
- 行覆盖率: 85%（基线 80% ✅）
- 分支覆盖率: 73%（基线 70% ✅）
- 主要路径: 100%（基线 100% ✅）
- 已排除：androidTest 下 3 个 Espresso 用例（需真机/模拟器，不计入）
```

## 基线标准

| 项目 | 要求 |
|------|------|
| 行覆盖率 | ≥ 80% |
| 分支覆盖率 | ≥ 70% |
| 主要路径 | 100% |
| 检测方式 | 必须执行项目覆盖率工具，以输出结果为准 |

## 检测流程

1. 运行项目覆盖率命令（根据项目类型）：

   | 项目类型 | 覆盖率命令 |
   |----------|-----------|
   | Gradle (Kotlin/Java) | `./gradlew testDebugUnitTest jacocoTestReport`（只跑单元测试）或项目已有的**单元测试**覆盖率命令 |
   | Maven | `mvn test jacoco:report`（Surefire 只跑 `*Test`，Failsafe 的 `*IT` 不计入） |
   | Node.js | `npm test -- --coverage`（排除 e2e 配置） |
   | Python | `pytest --cov=src --cov-report=term-missing`（不拉起外部服务） |
   | Go | `go test -short -coverprofile=coverage.out && go tool cover -func=coverage.out` |
   | 其他 | 检测环境时确定（见 `environment-detection.md`），后续统一使用 |

2. 读取覆盖率工具输出结果，逐项对比基线
3. 任一项不达标 → 补充**单元测试**（正常路径 + 边界 + 异常），重新运行直到达标。**不得靠加设备测试刷高数字**——那部分本来就不在分母里
4. **将实际覆盖率数值记录到任务完成报告中**，格式见上文「报告里必须写明口径」

## 禁止行为

- 凭代码行数或感觉推算覆盖率
- "大概够了"、"应该达标了"等主观判断
- 跳过覆盖率检查直接提交
- 凑数字写无意义测试（应覆盖正常路径 + 边界条件 + 异常场景）
- **把设备测试 / 数据库测试 / UI 测试的通过算作覆盖率达标**
- **把覆盖率命令写成会拉起模拟器或真实数据库的命令**，然后以「跑不起来」为由跳过

## 验证

- [ ] 覆盖率工具已实际运行
- [ ] 确认统计范围仅含可独立运行的单元测试（报告里写明了排除项）
- [ ] 行覆盖率 ≥ 80%
- [ ] 分支覆盖率 ≥ 70%
- [ ] 主要路径 100%
- [ ] 实际数值与命令口径已记录到完成报告
