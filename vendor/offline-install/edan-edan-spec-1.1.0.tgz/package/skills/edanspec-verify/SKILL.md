---
name: edanspec-verify
description: 三维度（完整性/正确性/一致性）+ 三级严重度报告。触发场景：feature 完成准备归档、用户要求「验证一下」「检查完成度」「看看还缺什么」。不适用于单行修复或小改动。
---

# 结构化验证

feature 归档前的最终关卡。"拿证据说话"——但结构化告诉你**需要什么证据**。

> **职责分工**：本 skill 负责流程编排（准备上下文 → 启动验证 → 判定结论）。验证维度定义、检查项细则、级别定义、输出格式以 `verifier-agent.md` 为准。
>
> **边界**：verify 只负责验证和写入报告文件。delta spec 合并和文件移动由 `edanspec-archive` 负责。动态测试和覆盖率由 `edanspec-task-implement` 的 5 项自动化验证完成，verify 仅做静态检查。

## 流程

### 1. 准备上下文

1. **扫描已有文件**：检查 `tasks.md`、`specs/*.md`、`design.md`、`proposal.md`（不存在的跳过）。
2. **记录产物缺失**：对每个不存在的文件，在报告中注明"缺少 XXX 文档，该维度部分检查项无法执行"，但**不得跳过整个维度**。
3. **确定报告输出**：落盘规则见 `../_shared/report-persistence.md`（本关卡写入 `{feature-dir}/verify-report.md`）。
   该参数传给步骤 2 的验证代理，代理根据此参数决定是否写入文件。

### 2. 启动 Verifier Subagent

读取 `verifier-agent.md` 全文，将 `{feature-dir}`、`{existing-files}`、`{report-target}` 替换为步骤 1 确定的值，
通过**当前平台的 subagent 机制**传给通用代理执行。

**平台适配**：以独立子 Agent 执行（保证结论客观），调用写法见 `../_shared/platform-adapters.md`。

prompt = verifier-agent.md 全文 + 参数替换。

### 3. 判定结论

验证代理执行完毕后，根据报告结论与严重度数字判定归档结论。**三态定义见 `edanspec-code-review` 的「判定规则」，与另两个关卡完全一致**；严重度数字只作依据，不作结论词。

| 报告结论 | 严重度特征 | 处理 |
|------|------|------|
| `REQUEST_CHANGES` | CRITICAL > 0 | 自动修复所有 CRITICAL → 删除 `verify-report.md` → 重新执行 verify |
| `INCOMPLETE` | 必要维度未完成或适用性无法确认 | **不自动修复，也不得归档**；先补齐未完成的检查项再重跑 |
| `APPROVE` | CRITICAL = 0 | 可归档；有 IMPORTANT 时报告保留，引导用户决定是否处理 |

> `edanspec-archive` 在遇到 CRITICAL 时拒绝归档，因为归档前 verify 必须已 passed。

**档位差异**：本技能在 STD 与 FULL 档都会被调用，差别只在执行形态——STD 档由 `edanspec-task-implement` 6.7 一次合并审查产出 `verify-report.md`，FULL 档独立执行。**两档的 `verify-report.md` 都必须存在且结论为 `APPROVE` 才能归档**。SLIM 档不调用本技能，由 6.6 自检代替，归档时核对 `change.md` 的「验证」段（详见 `../_shared/triage.md` 的档位后果表）。

## 本技能的红线信号

| 说辞 | 真相 |
|------|------|
| "代码能跑就不用验了" | 能跑 ≠ 完整。可能漏了异常处理和边界条件 |
| "小改动不需要验证" | 小改动最难回滚，漏一个 spec 就是生产 bug |
| "测试绿了就够了" | 测试绿 = 写了的测试通过了。spec 里没被写成测试的需求呢？ |

## 验证前证据

报告里必须出现这些**实际读到的东西**，不能只给结论：

- **三维度都跑了** — 需求覆盖 / 契约一致 / 回归，各自的执行方式与实际输出；某一维度降级时写明降级理由
- **每条发现** — `文件：行号` + 修复建议，以及引用的 spec 原文
- **严重度分布** — 报告严重度表的实际数字；只有 SUGGESTION 时说明为什么真的没有更严重的问题
- **结论一致性** — 有未解决的 CRITICAL 即为 failed，不得写 passed
