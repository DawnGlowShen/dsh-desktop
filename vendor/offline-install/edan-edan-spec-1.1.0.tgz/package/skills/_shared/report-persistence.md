# 审查报告持久化

三个审查关卡（code-review / security-review / verify）的报告落盘规则一致，各技能只保留自己那一行差异。

## 写到哪里

| 条件 | 操作 |
|------|------|
| 路径含 `EdanSpec/feature/` | 写入 `{feature-dir}/<关卡名>-report.md`，并把报告输出到控制台 |
| 不在 feature 目录下 | 仅输出报告到控制台，不写文件 |

各关卡的文件名：

| 关卡 | 报告文件 |
|------|---------|
| `edanspec-code-review` | `{feature-dir}/code-review-report.md` |
| `edanspec-security-review` | `{feature-dir}/security-review-report.md` |
| `edanspec-verify` | `{feature-dir}/verify-report.md` |

报告**必须写入文件**，`edanspec-task-implement` 步骤六据此基于文件系统事实判断关卡状态，不依赖会话记忆。

## 结论行

报告头部必须有结论行：`| **结论** | APPROVE / REQUEST_CHANGES / INCOMPLETE |`

三态定义以 `edanspec-code-review` 的「判定规则」为唯一来源，另两个关卡引用同一套。`INCOMPLETE` **不是通过**，不得被下游当作已完成，也不触发自动修复。

## 下游如何判定

- 状态推导规则见 `state-derivation.md`（结论行 → `passed` / `failed` / `incomplete`）
- `edanspec-archive` 在关卡结论为 `failed`（或 CRITICAL > 0）时拒绝归档
