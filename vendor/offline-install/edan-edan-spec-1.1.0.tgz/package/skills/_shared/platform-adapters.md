# 平台适配：启动隔离子 Agent

审查与验证类技能（code-review / security-review / verify）需要**在独立子进程中**执行，以保证结论的客观性。

| 平台 | 调用写法 |
|------|---------|
| Claude Code | `Agent tool`（通用代理），prompt = 待审查文件全文 + 上下文 |
| OpenCode | `task({ subagent_type: "general", prompt: 待审查文件全文 + 上下文 })` |

**上下文隔离**：子 Agent 只拿到 prompt 中显式传入的材料，不看主会话历史——这是审查独立性的来源，不要为了"省事"改为在主会话内直接审查。

> 引用方式：技能中以 `../_shared/platform-adapters.md` 指代本文件（相对技能目录）。各技能只补一句"prompt 装什么"即可，不重复本表。
