# Git 规范

## 核心原则

### 1. 原子提交
每个提交做一件完整的事，可独立回滚。按功能点拆分，不要把多个不相关的改动塞在一个提交里。

### 2. Trunk-Based 开发
默认在 main 分支工作，不长寿命特性分支。超过 3 个增量的任务才用短分支，合并后立即删除分支。

### 3. 提交前验证
- 构建通过、测试全绿
- 不夹带无关变更
- 敏感文件、密钥在 .gitignore 中，不入库
- 所有以 `.` 开头的隐藏文件/目录（如 `.claude/`、`.env`、`.vscode/`、`.idea/` 等）必须写入 .gitignore，不得入库
- 推荐配置 pre-commit hook 自动格式化、检查敏感信息

### 4. 提交消息格式

遵循 Conventional Commits 规范：

```
<type>(<scope>): <description>

变更要点：
1. [变更要点]
2. [变更要点]

影响分析：
<受本次变更影响的其他模块，如 auth、billing/order；无则写「无」>

[footer]

Co-Authored-By: <harness>
```

**Type 类型**：`feat` | `fix` | `refactor` | `test` | `docs` | `chore` | `style` | `perf`

**Scope（可选）**：变更影响的模块或功能，如 `user`、`auth`、`api`

**变更要点**：先写「变更要点：」独占一行，换行后用有序列表 `1.` `2.` 逐条列举，每条对应一件可独立验证的事；只有一条时也写 `1.`

**影响分析**：「影响分析：」独占一行，内容换行另起，列出受本次变更影响的**其他**模块、调用方或下游（不含本次直接改动的模块）；没有则写「无」。两处标题都用中文冒号 `：`，避免被 Git 当作 trailer 解析。

**Breaking Change**：在 type 后加 `!`，如 `feat(api)!: 移除旧版认证接口`

**Footer**：`BREAKING CHANGE: ...` / `Closes #123` / `Fixes #456`

> `Co-Authored-By: <harness>` 是 Git 标准的协作署名 metadata，AI 协作生成的提交**必须**包含此行。
>
> 署名值按**实际执行本次提交的 harness** 填写，例如 `Co-Authored-By: Claude Code`、`Co-Authored-By: DeepSeek Harness`。无法确定具体是哪个智能体时，统一使用 `Co-Authored-By: AI`——不要沿用示例里的名字。

#### EdanSpec 标记（流程产生的提交必填）

经 edanspec 流程产生的提交，footer 必须带上流程标记，用于统计「哪些代码来自哪次变更」：

| Trailer | 必填 | 取值 |
|---------|------|------|
| `EdanSpec-Change` | 是 | 变更目录名，即该 feature `status.json` 的 `name`（如 `20260520-user-login`） |
| `EdanSpec-Flow` | 是 | 档位：`SLIM` / `STD` / `FULL`，与该变更记录的档位一致 |
| `EdanSpec-Task` | 否 | 本提交对应的任务与增量，如 `Task-001/inc-2` |

```
feat: 实现任务创建功能

变更要点：
1. 新增 createTask 函数
2. 完成 Task-001 增量 1, 2

影响分析：
任务调度服务的调用方（workflow-service）

EdanSpec-Change: 20260520-user-login
EdanSpec-Flow: STD
EdanSpec-Task: Task-001/inc-2
Co-Authored-By: <harness>
```

三条硬性约束：

1. **Trailer 必须连成消息的最后一段，内部不得有空行。** Git 只解析最后一段 trailer 块——在 `EdanSpec-*` 与 `Co-Authored-By` 之间留空行，`git log --format='%(trailers:key=EdanSpec-Change)'` 会取到空值。手工写不可靠时用 `git interpret-trailers --in-place --trailer "EdanSpec-Change=$NAME" <消息文件>` 追加，它总能把 trailer 并入同一段。
2. **前缀用 `EdanSpec-` 而非裸 `Change`**，避免与 Gerrit 的 `Change-Id` 撞名。
3. **`EdanSpec/` 必须入库，不得写入 `.gitignore`。** 变更目录一旦被忽略，提交钩子与统计都无法在 git 视角下看到活跃变更。注意这条与上面「以 `.` 开头的隐藏目录必须忽略」不冲突——`EdanSpec/` 不以点开头。

## 分支管理

### 分支命名

| 类型 | 命名格式 | 示例 |
|------|---------|------|
| 新功能 | `feat/<简短描述>` | `feat/user-login` |
| 修复 | `fix/<简短描述>` | `fix/auth-token-expiry` |
| 紧急修复 | `hotfix/<简短描述>` | `hotfix/db-connection-leak` |

### 分支保护

- main 分支禁止 force push 和直接 push
- 所有合入 main 的变更必须通过 PR + 至少一人 review approve
- PR 合并后自动删除源分支

### Rebase 优先

- 合并前 `git rebase main` 保持线性历史，避免无意义的 merge commit
- 多人协作的共享分支用 `git merge`，避免 rebase 已推送的提交
- 交互式 rebase (`-i`) 用于合并琐碎提交、整理历史

## 常用操作

### 常规提交流程
1. `git status` 查看变更
2. `git add` 指定文件（禁止 `-A`）
3. `git diff --staged` 确认暂存内容
4. `git commit -m "消息"`
5. `git status` 确认工作区干净

### 合并冲突处理
1. 理解双方意图
2. 保留两边有效改动
3. 解决冲突后跑测试
4. `git add` + `git commit` 完成合并

### 回滚
- 安全回滚：`git revert <commit>`（保留历史）
- 危险回滚：`git reset --hard`（丢失历史，仅限本地未推送）
- 部分回退：`git checkout <commit> -- <文件>`（恢复单文件）

## Pull Request 规范

- PR 标题使用 Conventional Commits 格式
- 描述包含：变更目的、影响范围、测试方式、截图（UI 变更）
- 大 PR 拆分为多个小 PR，每个 PR 聚焦一个变更点
- 标记 `Draft` 状态表示未完成但想提前获取反馈

## Feature Flag

未完成功能需合并到 main 时使用：

- 前缀：`ENABLE_`
- 默认关闭
- 生命周期：创建 → 开发 → 验证 → 清理（3 个提交内）
- 禁止：长寿命 flag、嵌套超 2 层、核心业务逻辑放在 flag 分支内

## 数据库迁移

- 命名格式：`<timestamp>_<描述>.sql`，如 `20260508_add_user_avatar.sql`
- 每个 forward 脚本必须有对应的 `.down.sql` 反向脚本
- 迁移脚本不可修改，只能新增
- 禁止破坏性变更直接执行（删列、改类型），需分多步：新增 → 双写 → 迁移数据 → 删除旧字段
