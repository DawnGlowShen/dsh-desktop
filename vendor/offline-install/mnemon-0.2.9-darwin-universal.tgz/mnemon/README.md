# Mnemon darwin

Universal darwin artifact for `@mnemon-dev/mnemon` carrying arm64 and x64 slices.
Install `@mnemon-dev/mnemon` instead of a single-architecture artifact directly.
