/**
 * Point Git's Trace2 events at the git-ai daemon.
 *
 * git-ai attributes edits from Git's Trace2 events, which Git only emits when
 * `trace2.eventTarget` names the daemon's transport. Without that key a checkpoint still
 * succeeds, but later commits read back as `untracked` — the feature fails silently. The
 * daemon derives its socket from `$HOME`, so the value is per-user and may move between
 * launches (a restored home, a different account); the keys are therefore converged on
 * every plugin activation rather than written once at install time.
 *
 * ## Why `git config` rather than editing the file
 *
 * Parsing `~/.gitconfig` means owning a parser for a format Git defines, and it has a
 * failure that destroys data: reading a file the user keeps encrypted does not throw,
 * because `readFileSync(path, 'utf8')` substitutes U+FFFD for every undecodable byte, so
 * ciphertext looks like a configuration file that merely needs editing — and writing it
 * back replaces the file with mojibake.
 *
 * `git config` has none of that surface. Git parses its own format and refuses a file that
 * is not one (ciphertext, binary, a repository's own config). Modern Git also rewrites only
 * what changed, so comments, indentation and blank lines survive.
 *
 * The cost is that a pre-existing `trace2.eventTarget` is replaced rather than commented
 * out. That key belongs to git-ai: a user can only have set it for another installation,
 * and leaving theirs active alongside ours would point Git at a socket that is not the
 * daemon whose events this plugin needs.
 *
 * ## Why not an environment variable
 *
 * `GIT_CONFIG_COUNT`/`GIT_CONFIG_KEY_n`/`GIT_CONFIG_VALUE_n` would cover only the processes
 * this harness launches; a user typing `git commit` in their own terminal would bypass them
 * and lose attribution. The global file covers both.
 *
 * ## Windows uses a named pipe, not an AF_UNIX socket
 *
 * Git's `trace2.eventTarget` names a transport, and the correct value is platform-specific.
 * On Unix git-ai listens on a filesystem socket and the value carries the `af_unix:stream:`
 * scheme. Windows has no AF_UNIX support in this code path, so git-ai listens on a named
 * pipe and `DaemonConfig::trace2_event_target_for_path` returns the **bare path with no
 * scheme at all**:
 *
 *   Unix:    af_unix:stream:<home>/.git-ai/internal/daemon/trace2.sock
 *   Windows: \\.\pipe\git-ai-<sha256(<home>\.git-ai\internal)[:16]>-trace2
 *
 * The Windows hash input is the *absolute* internal directory — `DaemonConfig::from_internal_dir`
 * hashes the resolved path, so the home directory is part of the digest and each account gets
 * its own pipe. Feeding it a home-relative fragment yields a name that parses but that no
 * daemon ever listens on.
 *
 * Writing the wrong target is not a crash — Git cannot open the transport, emits nothing, and
 * every command still exits 0 — but no event ever reaches the daemon and attribution is lost
 * silently, which is exactly the failure this module exists to prevent.
 * @module @deepseek-ai/dsh-git-ai/trace2
 */
/**
 * Build the environment for the child `git`.
 *
 * Inherited redirections are removed so the run reports on the file it actually touches,
 * and Trace2 is switched off so reading that file can never depend on the sink it declares.
 *
 * @param source - The environment this process was started with.
 * @returns A copy safe to hand to `spawn`.
 */
export declare function gitChildEnvironment(source: NodeJS.ProcessEnv): NodeJS.ProcessEnv;
/** Logging surface used during activation; both channels are best-effort. */
export interface Trace2Logger {
    /** Record an informational summary of what this run changed. */
    info(message: string): void;
    /** Record a refusal or failure; the caller keeps activation alive regardless. */
    warn(message: string): void;
}
/** What one converge run did, so the caller can log and test the decision. */
export interface Trace2ConfigResult {
    /** The gitconfig that was inspected. */
    gitConfigPath: string;
    /** Trace2 event target desired for this user. */
    eventTarget: string;
    /** True when this run set a key to a value it did not already have. */
    changed: boolean;
    /**
     * Why Git refused to write, when it did.
     *
     * Absent from every other result, so a caller can tell "nothing needed doing" apart from
     * "the file was not touched on purpose". Git refusing is the normal outcome for a
     * gitconfig it cannot parse, such as one the user keeps encrypted.
     */
    refused?: string;
}
/** One Git invocation, injectable so tests never need the executable. */
export interface Trace2GitRunner {
    /**
     * Run Git, returning its exit status and captured output.
     *
     * Asynchronous on purpose: the child is a short-lived `git config` on a local file, and
     * a synchronous wait would freeze the host while it runs — the failure mode is a stale
     * Windows pipe that blocks until the timeout.
     *
     * @param args - Arguments after the executable name.
     * @returns what the process did; `status` is null when it could not be started.
     */
    run(args: readonly string[]): Promise<{
        status: number | null;
        stdout: string;
        stderr: string;
        error?: Error;
    }>;
}
/** Inputs required to converge Trace2 attribution. */
export interface Trace2ConfigOptions {
    /** User home directory; owns both the gitconfig and the daemon socket path. */
    homeDir: string;
    /** Gitconfig to edit; normally `~/.gitconfig`. */
    gitConfigPath: string;
    /** Logger receiving a one-line summary of every run. */
    logger: Trace2Logger;
    /** Test seam for running Git. */
    git?: Trace2GitRunner;
    /**
     * Host platform selecting the Trace2 transport.
     *
     * Defaults to the running platform; a test pins `'win32'` to assert the named-pipe
     * spelling from a Unix host.
     */
    platform?: NodeJS.Platform;
}
/**
 * The git-ai Trace2 event target for a home directory.
 *
 * @param homeDir - User home directory, which owns the daemon's socket.
 * @param platform - Host platform selecting the transport.
 * @returns a value suitable for `trace2.eventTarget`.
 */
export declare function gitAiTrace2EventTarget(homeDir: string, platform?: NodeJS.Platform): string;
/**
 * Converge the global gitconfig so git-ai can attribute this user's edits.
 *
 * Never throws for a missing gitconfig, which Git creates, and never removes a key the
 * user set elsewhere — `[trace2] eventTarget` is git-ai's own, and replacing whichever
 * value was there is the point. Every outcome is reported through the logger and returned,
 * so activation can neither be blocked nor silently misconfigured.
 *
 * @param options - home directory, gitconfig path, logger, and test seams.
 * @returns what this run changed, for logging and assertions.
 */
export declare function ensureGitAiTrace2Config(options: Trace2ConfigOptions): Promise<Trace2ConfigResult>;
/** Options for the production runner. */
export interface DefaultGitRunnerOptions {
    /**
     * Kill the child after this many milliseconds.
     *
     * Defaults to {@link GIT_CONFIG_TIMEOUT_MS}; a test lowers it to reach the timeout arm
     * without waiting fifteen seconds.
     */
    timeoutMs?: number;
}
/**
 * Build the Git runner used outside tests.
 *
 * The child is spawned asynchronously so a slow or blocked `git config` — a stale Windows
 * named pipe is the recorded case — never freezes the host event loop. The timeout kills
 * the child and reports it as an error, matching the shape a synchronous spawn produced.
 *
 * @param options - test-visible knobs; production passes nothing.
 * @returns a runner invoking the `git` on `PATH`.
 */
export declare function defaultGitRunner(options?: DefaultGitRunnerOptions): Trace2GitRunner;
/** One-line summary of a run. */
export declare function describeTrace2Run(result: Trace2ConfigResult): string;
//# sourceMappingURL=trace2.d.ts.map