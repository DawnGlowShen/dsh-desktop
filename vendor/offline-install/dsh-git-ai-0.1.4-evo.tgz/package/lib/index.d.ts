/**
 * Native git-ai bridge for the harness interception points. Listens on
 * `tools/pre-execute` / `tools/post-execute`, translates "which file an agent
 * edited, with which model, in which session" into git-ai's generic `agent-v1`
 * checkpoint payloads, and invokes `git-ai checkpoint <preset> --hook-input
 * stdin` with that JSON. git-ai itself is never modified: file-edit tools send
 * `ai_agent` checkpoints after a successful edit, and bash/pwsh tools bracket
 * every run with `pre_shell_command` / `post_shell_command` checkpoints so
 * git-ai's file snapshots attribute whatever the command changed.
 * @module @deepseek-ai/dsh-git-ai
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "dsh-git-ai";
export declare const inject: string[];
/** Plugin config: the git-ai executable, identity fields, and checkpoint knobs. */
export interface Config {
    /**
     * git-ai executable; a bare name resolves through PATH. The command is
     * shell-quoted, so a path with spaces is safe.
     */
    gitAiPath: string;
    /** The agent name stamped on every checkpoint (the `agent_name` field). */
    agentName: string;
    /** Explicit model stamp; empty falls back to `agent.options.model`. */
    model: string;
    /** The git-ai generic-integration preset to invoke (`agent-v1`). */
    checkpointPreset: string;
    /** git-ai invocation timeout in ms. */
    timeoutMs: number;
    /** Whether bash/pwsh tools emit pre/post shell checkpoints (default true). */
    trackBash: boolean;
    /**
     * Whether activation converges Git's Trace2 keys onto the git-ai daemon socket.
     *
     * Defaults to true: git-ai can only attribute edits when `trace2.eventTarget` names its
     * transport, and that value is per-user and can move between launches. Set false on
     * machines where the gitconfig is managed elsewhere; checkpoints still fire, they just
     * cannot reach the daemon.
     */
    trace2: boolean;
}
export declare const Config: z<Config>;
/**
 * Run the plugin: converge the Trace2 pointer, then register pre/post tool listeners that
 * fire git-ai checkpoints. Every git-ai failure is logged and swallowed so the agent flow
 * never breaks.
 *
 * Activation waits for the convergence, but the child `git config` is asynchronous, so the
 * host event loop keeps running while it does.
 *
 * @param ctx - Cordis context carrying the shell executor.
 * @param config - resolved plugin config.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map