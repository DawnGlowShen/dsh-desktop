/**
 * dsh-rewind host half: the `/rewind` command and the Claude-Code-style
 * checkpoint store, composed as one dual-face bundle row (the browser half
 * lives in `src/client/`).
 *
 * Rewind mechanism: planning is pure (`src/rewind.ts`); execution appends a
 * marker `user/message` whose `surfaceOp` replaces every surface node after the
 * target with itself, cutting only the model-visible surface
 * (`docs/architecture.md`).
 *
 * File restore (mode `both`) follows Claude Code's checkpointing: the plugin
 * backs up each tracked write-class edit BEFORE it happens (at the
 * `tools/execute` around-dispatch stage, so an approval short-circuit cannot
 * skip the capture and a denied call never records), commits the backup under
 * the turn's anchor message seq at `tools/post-execute`, and a rewind to
 * message N restores every backup anchored at or after N — modified files are
 * written back to their pre-edit content, files created after N are deleted.
 * Backups persist on disk under the dsh data directory (newest 100 message
 * groups per session), so restores work after a host restart, and they
 * read/write the real file system with plain `node:fs` — independent of the
 * fs service. See `src/snapshot.ts`.
 *
 * @module dsh-rewind
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type CleanupSettings } from './snapshot-cleanup.ts';
export { SnapshotStore } from './snapshot.ts';
export type { CheckpointEntry, FileImpact, PruneStaleReport, RestoreOutcome, RestoreJournal, RestoreJournalState, RestoreReconcileReport } from './snapshot.ts';
export declare const name = "dsh-rewind";
export declare const inject: string[];
/** Plugin config. */
export interface RewindConfig {
    /** Checkpoint store root (exact path; beats `DSH_REWIND_SNAPSHOT_DIR` and the harness-home default). */
    readonly snapshotDir?: string;
    /** Harness home override (`config.dshHome` > `$DSH_HOME` > `~/.dsh`); feeds the default snapshot/cleanup paths. */
    readonly dshHome?: string;
    /** In-place content dedup (identical before-content → link). Default `true`. */
    readonly dedup?: boolean;
}
/**
 * The plugin's full configuration: the ordinary store options plus the
 * user-editable cleanup policy. The two policy fields are `.volatile()`, so the
 * host resolves them into live references before `apply` and the Plugins page
 * exposes exactly them.
 *
 * The policy fields are named for WHAT they gate (the automatic sweep; the
 * `/snapshot-auto-cleanup` command's manual `run` ignores the switch), because
 * this entry's own `disabled:` flag sits beside them in the same document and a
 * bare `enabled` reads like the plugin switch.
 */
export interface Config extends RewindConfig, CleanupSettings {
}
/** The `Config` schema the host resolves and projects as this entry's form. */
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    snapshotDir: z<string, string, "plain">;
    dshHome: z<string, string, "plain">;
    dedup: z<boolean, boolean, "defined">;
    autoCleanupEnabled: z<boolean, boolean, "volatile-defined">;
    autoCleanupMaxAgeDays: z<number, number, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    snapshotDir: z<string, string, "plain">;
    dshHome: z<string, string, "plain">;
    dedup: z<boolean, boolean, "defined">;
    autoCleanupEnabled: z<boolean, boolean, "volatile-defined">;
    autoCleanupMaxAgeDays: z<number, number, "volatile-defined">;
}>>, "plain">;
/**
 * The settings entry id this plugin's configuration is addressed by: the PROFILE
 * ROW id from the bundle's patch, not this fiber's nested include id. The loader
 * mounts a bundle's rows under an `include:` scope, so the fiber id carries that
 * prefix while the configuration editor keys entries and profile patches by the
 * bare row id.
 * @param entryId - this fiber's Loader entry id, when it has one.
 * @returns the configuration key, or undefined without an entry.
 */
export declare function cleanupConfigKey(entryId: string | undefined): string | undefined;
/**
 * Register the `/rewind` command and the checkpoint pipeline (before-capture
 * at `tools/execute`, disk commit at `tools/post-execute`).
 *
 * The command is fs-independent and registers immediately. The checkpoint
 * pipeline needs `fs` to resolve tracked paths to their real display paths,
 * so it mounts through a dynamic `ctx.inject(['fs'])` — it takes effect
 * whenever the fs service becomes available (and never fails the plugin's
 * load when a deployment has no fs; without it, no entries are recorded and
 * `both` restores report "no tracked changes").
 *
 * Capture runs in `tools/execute` (the around-dispatch stage), NOT in
 * `tools/pre-execute`: a pre-execute `{ kind: 'ask' }` short-circuit from
 * another plugin (e.g. dsh-edit-approval) skips later pre-execute listeners,
 * and a denied call never dispatches — so approved calls are still captured,
 * denied calls never leave a pending entry behind. Entries are committed to
 * disk at `tools/post-execute` under the turn's anchor message seq.
 *
 * @param ctx - context carrying `commands`, `tools`, and an optional `fs`.
 * @param config - resolved plugin config: the store options (`snapshotDir`,
 *  `dshHome`, `dedup`) plus the live cleanup policy (`enabled`, `maxAgeDays`).
 */
export declare function apply(ctx: Context, config?: Config): void;
