/**
 * Native git-ai bridge for the harness interception points. Listens on
 * `tools/pre-execute` / `tools/post-execute`, translates "which file an agent
 * edited, with which model, in which session" into git-ai's generic `agent-v1`
 * checkpoint payloads, and invokes `git-ai checkpoint <preset> --hook-input
 * stdin` with that JSON. git-ai itself is never modified: file-edit tools send
 * `ai_agent` checkpoints after a successful edit, and bash/pwsh tools bracket
 * every run with `pre_shell_command` / `post_shell_command` checkpoints so
 * git-ai's file snapshots attribute whatever the command changed.
 * @module @deepseek-ai/dsh-git-ai
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "dsh-git-ai";
export declare const inject: string[];
/** Plugin config: the git-ai executable, identity fields, and checkpoint knobs. */
export interface Config {
    /**
     * git-ai executable; a bare name resolves through PATH. The command is
     * shell-quoted, so a path with spaces is safe.
     */
    gitAiPath: string;
    /** The agent name stamped on every checkpoint (the `agent_name` field). */
    agentName: string;
    /** Explicit model stamp; empty falls back to `agent.options.model`. */
    model: string;
    /** The git-ai generic-integration preset to invoke (`agent-v1`). */
    checkpointPreset: string;
    /** git-ai invocation timeout in ms. */
    timeoutMs: number;
    /** Whether bash/pwsh tools emit pre/post shell checkpoints (default true). */
    trackBash: boolean;
}
export declare const Config: z<Config>;
/**
 * Run the plugin: register pre/post tool listeners that fire git-ai checkpoints.
 * Every git-ai failure is logged and swallowed so the agent flow never breaks.
 * @param ctx - Cordis context carrying the shell executor.
 * @param config - resolved plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map